import java.lang.*;
import geotransform.coords.*;
import geotransform.ellipsoids.*;
import geotransform.transforms.*;

public class test_gdc_gcc
{
    static final int MAX_POINTS = 1; // total number of points
    
    public static void main(String argv[])
    {
       
        int i; // iterator
        
        Gcc_Coord_3d gcc[] = new Gcc_Coord_3d[MAX_POINTS];
        Gdc_Coord_3d gdc[] = new Gdc_Coord_3d[MAX_POINTS]; // these need to be the same length.

        
        for (i = 0;i<gdc.length;i++)
        {
            gdc[i] = new Gdc_Coord_3d(75,-80,-10000.0);
            gcc[i] = new Gcc_Coord_3d();
        }
        
        Gdc_To_Gcc_Converter.Init(new WE_Ellipsoid());
     
        Gdc_To_Gcc_Converter.Convert(gdc,gcc); // with array
       
        // print out the sample data
        for (i=0;i<gdc.length;i++)
        {
            
            System.out.println("\nGdc[" + i + "].latitude: " + gdc[i].latitude);
            System.out.println("Gdc[" + i + "].longitude: " + gdc[i].longitude);
            System.out.println("Gdc[" + i + "].elevation: " + gdc[i].elevation);
        
            System.out.println("\nGcc[" + i + "].x: " + gcc[i].x);
            System.out.println("Gcc[" + i +"].y: " + gcc[i].y);
            System.out.println("Gcc[" + i + "].z: " + gcc[i].z);
        } // end for
        
    } // end main
}// end test
