import java.lang.*;
import geotransform.coords.*;
import geotransform.ellipsoids.*;
import geotransform.transforms.*;

public class test_gcc_utm
{
    static final int MAX_POINTS = 1; // total number of points
    
    public static void main(String argv[])
    {
       
        int i; // iterator
        
        Gcc_Coord_3d gcc[] = new Gcc_Coord_3d[MAX_POINTS];
        Utm_Coord_3d utm[] = new Utm_Coord_3d[MAX_POINTS]; // these need to be the same length.

        
        
        for (i = 0;i<gcc.length;i++)
        {
            utm[i] = new Utm_Coord_3d();
            gcc[i] = new Gcc_Coord_3d(287105.51440612687,-1628256.2841634569,6129106.424081606);
        }
        
        Gcc_To_Utm_Converter.Init(new WE_Ellipsoid());        
  
        // convert the points.
     
        Gcc_To_Utm_Converter.Convert(gcc,utm); // with array
       
        // print out the sample data
        for (i=0;i<gcc.length;i++)
        {
            System.out.println("\nGcc[" + i + "].x: " + gcc[i].x);
            System.out.println("Gcc[" + i +"].y: " + gcc[i].y);
            System.out.println("Gcc[" + i + "].z: " + gcc[i].z);    
                    
            System.out.println("\nUtm[" + i + "].x: " + utm[i].x);
            System.out.println("Utm[" + i +"].y: " + utm[i].y);
            System.out.println("Utm[" + i + "].z: " + utm[i].z);
            System.out.println("Utm[" +i + "].zone: " + utm[i].zone);
            System.out.println("Utm[" + i + "].hemisphere_north: " + utm[i].hemisphere_north);  
        

        } // end for
        
    } // end main
}// end test
