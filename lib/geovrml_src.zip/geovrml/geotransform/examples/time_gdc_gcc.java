import java.lang.*;
import java.util.Date;
import geotransform.coords.*;
import geotransform.ellipsoids.*;
import geotransform.transforms.*;

public class time_gdc_gcc {

  static final int MAX_ITERS = 100000;
    
  public static void main(String argv[]) {
    
    double latitude = 0.0, longitude = 0.0;
    Gcc_Coord_3d gcc = new Gcc_Coord_3d();
    Gdc_Coord_3d gdc = new Gdc_Coord_3d();

    // initialise the GDC->GCC converter
    
    Gdc_To_Gcc_Converter.Init(new WE_Ellipsoid());

    // Start the timer running
    
    Date start_time = new Date();

    // convert MAX_ITERS different GDC points to GCC

    for ( int i = 0; i < MAX_ITERS; i++ ) {
      gdc.latitude = latitude;
      gdc.longitude = longitude;

      Gdc_To_Gcc_Converter.Convert( gdc, gcc );

      latitude += 1.0; if ( latitude > 90.0 ) latitude -= 180.0;
      longitude += 1.0; if ( longitude > 180.0 ) latitude -= 360.0;
    }
        
    // Grab the end time

    Date end_time = new Date();

    // Find out how long the above operation took

    long elapsed = end_time.getTime() - start_time.getTime();
    double persec = ( 1000.0 / (double) elapsed ) * (double) MAX_ITERS;

    System.out.println( "Number of iterations = " + MAX_ITERS );
    System.out.println( "Time for calculations = " + elapsed + " ms" );
    System.out.println( "Calcs per second = " + persec );
    
  }
}
