//
// Filename: test_gdc_Lambert.java
//
// Author: Jesus Diaz Centeno, Batmap S.A.
//
// Package: GeoTransform <http://www.ai.sri.com/geotransform/>
//
// Acknowledgements:
//   The algorithms used in the package were created by Jesus Diaz Centeno.
//
// License:
//   The contents of this file are subject to GeoTransform License Agreement
//   (the "License"); you may not use this file except in compliance with
//   the License. You may obtain a copy of the License at
//   http://www.ai.sri.com/geotransform/license.html
//
//   Software distributed under the License is distributed on an "AS IS"
//   basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See
//   the License for the specific language governing rights and limitations
//   under the License.
//
//   Portions are Copyright (c) Batmap S.A. 2002.
//

import java.lang.*;
import java.io.*;
import geotransform.coords.*;
import geotransform.ellipsoids.*;
import geotransform.transforms.*;
import geotransform.datum.*;

public class test_gdc_Lambert
{
    static final int MAX_POINTS = 1; // total number of points

    public static void main(String argv[]) throws IOException
    {

        int i; // iterator
	double lat, lon, h;
	String s1, s2, s3;
	DataInput d = new DataInputStream(System.in);

        // Gdc_Coord_3d gdc[] = new Gdc_Coord_3d[MAX_POINTS]; // these need to be the same length.
        // Lambert_Coord_3d Lambert[] = new Lambert_Coord_3d[MAX_POINTS];

	Gdc_Coord_3d gdc_point = new Gdc_Coord_3d();
        Lambert_Coord_3d Lambert_point = new Lambert_Coord_3d();



	while (gdc_point.latitude != -999.0) {
	  System.out.print("Latitud? ");
	  System.out.flush();
	  s1 = d.readLine();
	  System.out.print("Longitud? ");
	  System.out.flush();
	  s2 = d.readLine();
	  System.out.print("Altitud? ");
	  System.out.flush();
	  s3 = d.readLine();

	  gdc_point = new Gdc_Coord_3d(Double.valueOf(s1).doubleValue(), Double.valueOf(s2).doubleValue(),Double.valueOf(s3).doubleValue());
	  // convert the points.

          Gdc_To_Lambert_Converter.Init(new IN_Ellipsoid());

          Gdc_To_Lambert_Converter.Convert(gdc_point,Lambert_point); // with points

	  System.out.println("\nLambert.x: " + Lambert_point.x);
	  System.out.println("Lambert.y: " + Lambert_point.y);
	  System.out.println("Lambert.z: " + Lambert_point.z);
	} // while
    } // end main
}// end test
