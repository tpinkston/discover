import java.lang.*;
import geotransform.coords.*;
import geotransform.ellipsoids.*;
import geotransform.transforms.*;

public class test_gcc_gdc
{
    static final int MAX_POINTS = 1; // total number of points

    public static void main(String argv[])
    {

        int i; // iterator

	Gcc_Coord_3d gcc[] = new Gcc_Coord_3d[MAX_POINTS];
	Gdc_Coord_3d gdc[] = new Gdc_Coord_3d[MAX_POINTS]; // these need to be the same length.

	Gcc_To_Gdc_Converter.Init(new WE_Ellipsoid());

	Gdc_Coord_3d gdc_point = new Gdc_Coord_3d();
	Gcc_Coord_3d gcc_point = new Gcc_Coord_3d(287105.51440612687,-1628256.2841634569,6129106.424081606);

	// convert the points.

	Gcc_To_Gdc_Converter.Convert(gcc_point,gdc_point); // with points

	System.out.println("\nGcc.x: " + gcc_point.x);
	System.out.println("Gcc.y: " + gcc_point.y);
	System.out.println("Gcc.z: " + gcc_point.z);

	System.out.println("\nGdc.latitude: " + gdc_point.latitude);
	System.out.println("Gdc.longitude: " + gdc_point.longitude);
	System.out.println("Gdc.elevation: " + gdc_point.elevation);

    } // end main
}// end test
