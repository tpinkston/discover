//
// Filename: test_OSGB_gdc.java
//
// Author: Jesus Diaz Centeno, Batmap S.A.
//
// Package: GeoTransform <http://www.ai.sri.com/geotransform/>
//
// Acknowledgements:
//   The algorithms used in the package were created by Jesus Diaz Centeno.
//
// License:
//   The contents of this file are subject to GeoTransform License Agreement
//   (the "License"); you may not use this file except in compliance with
//   the License. You may obtain a copy of the License at
//   http://www.ai.sri.com/geotransform/license.html
//
//   Software distributed under the License is distributed on an "AS IS"
//   basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See
//   the License for the specific language governing rights and limitations
//   under the License.
//
//   Portions are Copyright (c) Batmap S.A. 2001.
//

import java.lang.*;
import java.io.*;
import geotransform.coords.*;
import geotransform.ellipsoids.*;
import geotransform.transforms.*;
import geotransform.datum.*;

public class test_OSGB_gdc
{
    static final int MAX_POINTS = 1; // total number of points

    public static void main(String argv[]) throws IOException
    {

    int i; // iterator
	double lat, lon, h;
	String s1, s2, s3;
	DataInput d = new DataInputStream(System.in);

        // Gdc_Coord_3d gdc[] = new Gdc_Coord_3d[MAX_POINTS]; // these need to be the same length.
        // OSGB_Coord_3d OSGB[] = new OSGB_Coord_3d[MAX_POINTS];

    Gdc_Coord_3d gdc_point = new Gdc_Coord_3d();
    OSGB_Coord_3d OSGB_point = new OSGB_Coord_3d();

          s1="651409.903";
          s2="313177.270";
          s3="24.700";
	  OSGB_point = new OSGB_Coord_3d(Double.valueOf(s1).doubleValue(), Double.valueOf(s2).doubleValue(),Double.valueOf(s3).doubleValue(),true);
	  // convert the points.


	  System.out.println("\nOSGB.x: " + OSGB_point.x);
	  System.out.println("OSGB.y: " + OSGB_point.y);
	  System.out.println("OSGB.z: " + OSGB_point.z);

		OSGB_To_Gdc_Converter.Init(new AA_Ellipsoid());


        OSGB_To_Gdc_Converter.Convert(OSGB_point,gdc_point); // with points

  	  System.out.println("\nGdc.latitude: " + gdc_point.latitude);
	  System.out.println("Gdc.longitude: " + gdc_point.longitude);
	  System.out.println("Gdc.elevation: " + gdc_point.elevation);



    } // end main
}// end test
