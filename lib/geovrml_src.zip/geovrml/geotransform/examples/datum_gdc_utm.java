//
// Filename: Datum_gdc_utm.java
//
// Author: Jesus Diaz Centeno, Batmap S.A.
//
// Package: GeoTransform <http://www.ai.sri.com/geotransform/>
//
// Acknowledgements:
//   The algorithms used in the package were created by Jesus Diaz Centeno.
//
// License:
//   The contents of this file are subject to GeoTransform License Agreement
//   (the "License"); you may not use this file except in compliance with
//   the License. You may obtain a copy of the License at
//   http://www.ai.sri.com/geotransform/license.html
//
//   Software distributed under the License is distributed on an "AS IS"
//   basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See
//   the License for the specific language governing rights and limitations
//   under the License.
//
//   Portions are Copyright (c) Batmap S.A. 2001.
//

import java.lang.*;
import java.io.*;
import geotransform.coords.*;
import geotransform.ellipsoids.*;
import geotransform.transforms.*;
import geotransform.datum.*;

public class Datum_gdc_utm
{
    static final int MAX_POINTS = 1; // total number of points

    public static void main(String argv[]) throws IOException
    {

        int i; // iterator
	double lat, lon, h;
	String s1, s2, s3;
	DataInput d = new DataInputStream(System.in);

        // Gdc_Coord_3d gdc[] = new Gdc_Coord_3d[MAX_POINTS]; // these need to be the same length.
        // Utm_Coord_3d utm[] = new Utm_Coord_3d[MAX_POINTS];

	Gdc_Coord_3d gdc_point = new Gdc_Coord_3d();
	Gcc_Coord_3d gcc_point = new Gcc_Coord_3d();
	Gcc_Coord_3d gcc_point_out = new Gcc_Coord_3d();
        Utm_Coord_3d utm_point = new Utm_Coord_3d();



	while (gdc_point.latitude != -999.0) {
	  System.out.print("Latitud? ");
	  System.out.flush();
	  s1 = d.readLine();
	  System.out.print("Longitud? ");
	  System.out.flush();
	  s2 = d.readLine();
	  System.out.print("Altitud? ");
	  System.out.flush();
	  s3 = d.readLine();

	  gdc_point = new Gdc_Coord_3d(Double.valueOf(s1).doubleValue(), Double.valueOf(s2).doubleValue(),Double.valueOf(s3).doubleValue());
	  // convert the points.
          Gdc_To_Gcc_Converter.Init(new WE_Ellipsoid());

	  Gdc_To_Gcc_Converter.Convert(gdc_point,gcc_point); // with points

	  System.out.println("\nGdc.latitude: " + gdc_point.latitude);
	  System.out.println("Gdc.longitude: " + gdc_point.longitude);
	  System.out.println("Gdc.elevation: " + gdc_point.elevation);

	  System.out.println("\nGcc.x: " + gcc_point.x);
	  System.out.println("Gcc.y: " + gcc_point.y);
	  System.out.println("Gcc.z: " + gcc_point.z);

          //Datum
          Create_Datum Lista_Datum=new Create_Datum();
          Lista_Datum.Init();
     	  Datum.Convert(Lista_Datum.Lista[75],true,gcc_point,gcc_point_out); // with points

	  System.out.println("\nGcc.x: " + gcc_point_out.x);
	  System.out.println("Gcc.y: " + gcc_point_out.y);
	  System.out.println("Gcc.z: " + gcc_point_out.z);

          Gcc_To_Gdc_Converter.Init(new IN_Ellipsoid());

          Gcc_To_Gdc_Converter.Convert(gcc_point_out,gdc_point); // with points

       	  System.out.println("\nGdc.latitude: " + gdc_point.latitude);
	  System.out.println("Gdc.longitude: " + gdc_point.longitude);
	  System.out.println("Gdc.elevation: " + gdc_point.elevation);

          Gdc_To_Utm_Converter.Init(new IN_Ellipsoid());

          Gdc_To_Utm_Converter.Convert(gdc_point,utm_point,-1); // with points

	  System.out.println("\nUtm.x: " + utm_point.x);
	  System.out.println("Utm.y: " + utm_point.y);
	  System.out.println("Utm.z: " + utm_point.z);
	} // while
    } // end main
}// end test
