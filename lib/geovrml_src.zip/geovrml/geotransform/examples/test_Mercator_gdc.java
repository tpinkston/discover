//
// Filename: test_Mercator_gdc.java
//
// Author: Jesus Diaz Centeno, Batmap S.A.
//
// Package: GeoTransform <http://www.ai.sri.com/geotransform/>
//
// Acknowledgements:
//   The algorithms used in the package were created by Jesus Diaz Centeno.
//
// License:
//   The contents of this file are subject to GeoTransform License Agreement
//   (the "License"); you may not use this file except in compliance with
//   the License. You may obtain a copy of the License at
//   http://www.ai.sri.com/geotransform/license.html
//
//   Software distributed under the License is distributed on an "AS IS"
//   basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See
//   the License for the specific language governing rights and limitations
//   under the License.
//
//   Portions are Copyright (c) Batmap S.A. 2002.
//

import java.lang.*;
import java.io.*;
import geotransform.coords.*;
import geotransform.ellipsoids.*;
import geotransform.transforms.*;
import geotransform.datum.*;

public class test_Mercator_gdc
{
    static final int MAX_POINTS = 1; // total number of points

    public static void main(String argv[])
    {

        int i; // iterator

        Gdc_Coord_3d gdc[] = new Gdc_Coord_3d[MAX_POINTS]; // these need to be the same length.
        Mercator_Coord_3d Mercator[] = new Mercator_Coord_3d[MAX_POINTS];
      	Gcc_Coord_3d gcc[] = new Gcc_Coord_3d[MAX_POINTS];
	Gcc_Coord_3d gcc_out[] = new Gcc_Coord_3d[MAX_POINTS];


        for (i = 0;i<gdc.length;i++)
        {
            gdc[i] = new Gdc_Coord_3d();
	    Mercator[i] = new Mercator_Coord_3d(-333958.4723798207,4838471.398061136,0,true);
            gcc[i] = new Gcc_Coord_3d();
            gcc_out[i] = new Gcc_Coord_3d();
        }

        Mercator_To_Gdc_Converter.Init(new WE_Ellipsoid());

        // convert the points. Mercator a GEO sobre elipsoide IN

        Mercator_To_Gdc_Converter.Convert(Mercator,gdc);


        // print out the sample data
        for (i=0;i<gdc.length;i++)
        {
            System.out.println("\nMercator[" + i + "].x: " + Mercator[i].x);
            System.out.println("Mercator[" + i +"].y: " + Mercator[i].y);
            System.out.println("Mercator[" + i + "].z: " + Mercator[i].z);
            System.out.println("Mercator[" + i + "].hemisphere_north: " + Mercator[i].hemisphere_north);

            System.out.println("\nGdc[" + i + "].latitude: " + gdc[i].latitude);
            System.out.println("Gdc[" + i + "].longitude: " + gdc[i].longitude);
            System.out.println("Gdc[" + i + "].elevation: " + gdc[i].elevation);


        } // end for
    } // end main
}// end test
