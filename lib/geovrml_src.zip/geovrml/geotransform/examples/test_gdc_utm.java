import java.lang.*;
import geotransform.coords.*;
import geotransform.ellipsoids.*;
import geotransform.transforms.*;

public class test_gdc_utm
{
    static final int MAX_POINTS = 1; // total number of points

    public static void main(String argv[])
    {

        int i; // iterator

        // Gdc_Coord_3d gdc[] = new Gdc_Coord_3d[MAX_POINTS]; // these need to be the same length.
        // Utm_Coord_3d utm[] = new Utm_Coord_3d[MAX_POINTS];

        Gdc_To_Utm_Converter.Init(new WE_Ellipsoid());

        Gdc_Coord_3d gdc_point = new Gdc_Coord_3d(-80,-180,-10000.0);
        Utm_Coord_3d utm_point = new Utm_Coord_3d();

        // convert the points.

        Gdc_To_Utm_Converter.Convert(gdc_point,utm_point); // with points

        System.out.println("\nGdc.latitude: " + gdc_point.latitude);
        System.out.println("Gdc.longitude: " + gdc_point.longitude);
        System.out.println("Gdc.elevation: " + gdc_point.elevation);

        System.out.println("\nUtm.x: " + utm_point.x);
        System.out.println("Utm.y: " + utm_point.y);
        System.out.println("Utm.z: " + utm_point.z);
        System.out.println("Utm.zone: " + utm_point.zone);
        System.out.println("Utm.hemisphere_north: " + utm_point.hemisphere_north);

    } // end main
}// end test
