//
// Filename: GeoTransform.java
//
// Authors:
//   Mike McCann, MBARI - 17 December 2001
//
// Purpose:
//   This class implements a new Transform node for VRML. It allows you
//   to take any GeoVRML geometry and adjust its GeoLocation with relative
//   local VRML coordinate system translation and oriantation settings.
//
//   This code requires access to the GeoTransform Java package (not to be
//   confused with the name of this node), included as part of the GeoVRML
//   source code distribution.
//
// License:
//   The contents of this file are subject to GeoVRML Public License
//   Version 1.1 (the "License"); you may not use this file except in
//   compliance with the License. You may obtain a copy of the License at
//   http://www.geovrml.org/1.1/license/.
//
//   Software distributed under the License is distributed on an "AS
//   IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
//   implied. See the License for the specific language governing
//   rights and limitations under the License.
//
//   Portions are Copyright (c) SRI International, 2000.
//
// Revision:
//  $Id: GeoTransform.java,v 1.3 2003/07/21 18:08:01 mccann Exp $
//
//  Martin Reddy (21 Aug 1999) - initial version
//  John Brecht (31 Mar 2000) - support set_geoCoords eventIn
//  Mike McCann (4 Dev 2001) - modeled after work above for GeoLocation.java
//

import java.lang.*;
import vrml.*;
import vrml.field.*;
import vrml.node.*;
import geotransform.coords.Gcc_Coord_3d;
import geotransform.coords.Gdc_Coord_3d;
import org.web3d.geovrml.GeoVRML;
import org.web3d.geovrml.Quaternion;

public class GeoTransform extends Script {

  MFString geoSystem;
  SFNode geoOrigin;
  SFString geoCenter;
  GeoVRML geovrml;
  Node transform;
  boolean debug;
  SFString geoCenter_changed;
  SFVec3f translation_changed;
  SFRotation rotation_changed;
  Gcc_Coord_3d gcc;
  Gdc_Coord_3d gdc;
  SFVec3f xform_cen;

  public void processEvent( Event e ) {

    // Need to process rotation event before translation event

    String name = e.getName();

    if ( debug ) System.out.println( "Event received: " + name );


    if ( name.equals( "set_rotation" ) ) {
      ConstSFRotation csfrot = (ConstSFRotation) e.getValue();
      SFRotation sfrot = new SFRotation();
      sfrot.setValue(csfrot);
      // process the set_rotation eventIn by calling updateGeoOrientation()
      // and produce the rotation_changed eventOut.
      updateGeoOrientation(sfrot);
      rotation_changed.setValue(sfrot);
    }
    else if ( name.equals( "set_translation" ) ) {
      ConstSFVec3f csfvec3f = (ConstSFVec3f) e.getValue();
      SFVec3f sfvec3f = new SFVec3f();
      sfvec3f.setValue(csfvec3f);
      // process the set_translation eventIn by calling updateGeoTranslation()
      // and produce the translation_changed eventOut.
      updateGeoTranslation(sfvec3f);
      translation_changed.setValue(sfvec3f);
    }
    else if ( name.equals( "set_geoCenter" ) ) {
      ConstSFString csfstring = (ConstSFString) e.getValue();
      SFString sfstring = new SFString();
      sfstring.setValue(csfstring);

      // Set center of rotation to the geoCenter specified
      // and produce geoCenter_changed eventOut
      gcc = geovrml.getCoord( sfstring, geoSystem );
      if ( debug ) System.out.println( "  processEvent(): xform_cen set to " + gcc.x + ", " + gcc.y + ", " + gcc.z);
      xform_cen.setValue( (float) gcc.x, (float) gcc.y, (float) gcc.z);
      geoCenter_changed.setValue(sfstring);
    }
  }


  // The initialize method is called when the Node is first loaded.
  // Here we grab copies of any necessary fields/eventIn/eventOuts
  // and do the coordinate transformation in order to compute the
  // correct translations and rotations for the transform's childrens.

  public void initialize() {

    // Take copies of all the fields for this node

    geoOrigin = (SFNode) getField( "geoOrigin" );
    geoSystem = (MFString) getField( "geoSystem" );
    
    Node def_geoCenter = (Node) ((SFNode) getField( "def_geoCenter" )).getValue();
    SFString geoCenter = (SFString) def_geoCenter.getExposedField( "description" );
    
    Node def_translation = (Node) ((SFNode) getField( "def_translation" )).getValue();
    SFVec3f translation = (SFVec3f) def_translation.getExposedField( "axisOfRotation" );
    
    Node def_rotation = (Node) ((SFNode) getField( "def_rotation" )).getValue();
    SFRotation rotation = (SFRotation) def_rotation.getExposedField( "orientation" );
    
    //geoCenter = (SFString) getField( "geoCenter" );
    //SFVec3f translation = (SFVec3f) getField( "translation" );
    //SFRotation rotation = (SFRotation) getField( "rotation" );
    
    transform = (Node) ((SFNode) getField( "transform" )).getValue();
    debug = ((SFBool) getField( "debug" )).getValue();
    geoCenter_changed = (SFString) getEventOut( "geoCenter_changed" );
    translation_changed = (SFVec3f) getEventOut( "translation_changed" );
    rotation_changed = (SFRotation) getEventOut( "rotation_changed" );

    if ( debug ) System.out.println( "GeoTransform:" );

    // Okay, let's initialise the GeoVRML utility class
    // These classes should be installed on the user's system and in
    // their CLASSPATH. If they are not, then we can't do anything!

    try {
      geovrml = new GeoVRML();
    } catch ( NoClassDefFoundError e ) {
      System.out.println( "GeoTransform classes not installed in CLASSPATH!" );
      return;
    }

    geovrml.setOrigin( geoOrigin );

    // Set center of rotation to the geoCenter specified
    gcc = geovrml.getCoord( geoCenter, geoSystem );
    xform_cen = (SFVec3f) transform.getExposedField( "center" );
    xform_cen.setValue( (float) gcc.x, (float) gcc.y, (float) gcc.z);

    // Compute rotation before translation
    updateGeoOrientation(rotation);
    updateGeoTranslation(translation);

  }

  // Converts the inputed geoCenter to GCC and sets the translation
  // of the Node appropriately.

  public void updateGeoTranslation(SFVec3f translation) {
    // Find out the location that the user wants to georeference to
    // This is essentially the translation vector for the transform

    // Coordinate of "midpoint" of child nodes to be relatively translated
    // The passed geoCenter needs to refer to the geo location of where the
    // relative translations are done.

    float x, y, z;
    x = translation.getX();
    y = translation.getY();
    z = translation.getZ();

    SFVec3f xform_trans = (SFVec3f) transform.getExposedField( "translation" );

    if ( debug ) {
      System.out.println( "  updateGeoTranslation(): translation = " + translation.getX() +
        " "+ translation.getY() +" "+ translation.getZ() );
      System.out.println( "  updateGeoTranslation(): xform_trans = " + xform_trans.getX() +
        " "+ xform_trans.getY() +" "+ xform_trans.getZ() );
    }

    // Now let's work out the orientation at that location in order
    // to maintain a view where +Y is in the direction of gravitional
    // up for that region of the planet's surface. This will be the
    // value of the rotation vector for the transform.

    float orient[] = new float[4];
    geovrml.getLocalOrientation( gcc, orient );

    if ( debug ) {
      System.out.println( "  updateGeoTranslation(): rotation = " + orient[0] + " " + orient[1] +
			  " " + orient[2] + " " + orient[3] + " (" +
			  orient[3] * 57.29578f + " deg)" );
    }

    // Need to apply child node's rotation to the relative x, y, z point before
    // appling to child node's translation.
    // Use quaternions to do the rotation math.  See:
    // http://www.cs.berkeley.edu/~laura/cs184/quat/quatproof.html

    Quaternion P_quat  = new Quaternion( (double) x, (double) y, (double) z, 0.0);
    Quaternion q_quat  = new Quaternion();
    Quaternion P_quatrot  = new Quaternion();
    Quaternion tmp_quat  = new Quaternion();          // Temp quaternion

    q_quat.rotation( (double) orient[0], (double) orient[1],
			  (double) orient[2], (double) orient[3] * 57.29578f );
    Quaternion q_quatinv = new Quaternion( (double) -q_quat.x,
                          (double) -q_quat.y, (double) -q_quat.z, q_quat.w);

    tmp_quat.multiply( P_quat, q_quatinv );
    P_quatrot.multiply( q_quat, tmp_quat );

    if ( debug )
      System.out.println( "  updateGeoTranslation(): new translation = " + P_quatrot.x +
                  " " + P_quatrot.y + " " + P_quatrot.z );
    xform_trans.setValue( (float) P_quatrot.x, (float) P_quatrot.y,
                  (float) P_quatrot.z );

  } // End updateGeoTranslation()


  // Converts the inputed geoCenter to GCC and sets the rotation
  // of the Node appropriately.

  public void updateGeoOrientation(SFRotation rotation) {

    // The rotation to apply to the children's transform

    SFRotation xform_rot = (SFRotation) transform.getExposedField( "rotation" );

    if ( debug ) {
      System.out.println( "  updateGeoOrientation(): amount to rotate = " + rotation.toString() );
      System.out.println( "  updateGeoOrientation():Transform's: ");
      System.out.println( "  updateGeoOrientation(): rotation = " + xform_rot.toString() );
      //System.out.println( "  updateGeoOrientation(): center = " + xform_cen.toString() );
      System.out.println( "  updateGeoOrientation(): gcc translation = " + gcc.x + " " + gcc.y + " " + gcc.z );
    }

    // Now let's work out the orientation at that location in order
    // to maintain a view where +Y is in the direction of gravitional
    // up for that region of the planet's surface. This will be the
    // value of the rotation vector for the transform.

    float orient[] = new float[4];
    geovrml.getLocalOrientation( gcc, orient );

    if ( debug )
      System.out.println( "  updateGeoOrientation(): orient = " + orient[0] + " " + orient[1] +
			  " " + orient[2] + " " + orient[3] + " (" +
			  orient[3] * 57.29578f + " deg)" );

    // Need to rotate the the new rotation vector to the
    // LVCS oriatation.
    float relOrient[] = new float[4];
    rotation.getValue( relOrient );

    Quaternion P_quat  = new Quaternion( (double) relOrient[0], (double) relOrient[1], (double) relOrient[2], 0.0);
    Quaternion q_quat  = new Quaternion();
    Quaternion P_quatrot  = new Quaternion();
    Quaternion tmp_quat  = new Quaternion();          // Temp quaternion

    q_quat.rotation( (double) orient[0], (double) orient[1],
			  (double) orient[2], (double) orient[3] * 57.29578f );
    Quaternion q_quatinv = new Quaternion( (double) -q_quat.x,
                          (double) -q_quat.y, (double) -q_quat.z, q_quat.w);

    tmp_quat.multiply( q_quat, P_quat );
    P_quatrot.multiply( tmp_quat, q_quatinv );

    SFRotation rot = new SFRotation( (float) P_quatrot.x, (float) P_quatrot.y,
                           (float) P_quatrot.z, (float) relOrient[3] );

    if ( debug )
      System.out.println( "  updateGeoOrientation(): new rotation orient + ang = " + rot.toString() );

    xform_rot.setValue( rot );

  } // End updateGeoOrientation()
}

// EOF: GeoTransform.java
