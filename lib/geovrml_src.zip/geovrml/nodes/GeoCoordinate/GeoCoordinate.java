//
// Filename: GeoCoordinate.java
//
// Author:
//   Martin Reddy, SRI International.
//
// Purpose:
//   This class implements a new Coordinate node for VRML. It enables the
//   specification of coordinates in coordinate systems other than the
//   basic VRML Cartesian XYZ system. We support a number of geographic
//   coordinate systems such as lat/long and UTM.
//
//   This code requires access to the GeoTransform Java package, included
//   as part of the GeoVRML source code distribution.
//
// License:
//   The contents of this file are subject to GeoVRML Public License
//   Version 1.0 (the "License"); you may not use this file except in
//   compliance with the License. You may obtain a copy of the License at
//   http://www.geovrml.org/1.0/license/.
//
//   Software distributed under the License is distributed on an "AS
//   IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
//   implied. See the License for the specific language governing
//   rights and limitations under the License.
//
//   Portions are Copyright (c) SRI International, 2000.
//
// Revision:
//   $Id: GeoCoordinate.java,v 1.1.1.1 2000/06/15 16:49:27 reddy Exp $
//

import java.lang.*;
import vrml.*;
import vrml.field.*;
import vrml.node.*;
import geotransform.coords.Gcc_Coord_3d;
import org.web3d.geovrml.GeoVRML;

public class GeoCoordinate extends Script {
  
  // The initialize method is called when the Node is first loaded.
  // Here we grab copies of any necessary fields/eventIn/eventOuts
  // and do the coordinate transformation in order to create a
  // a point array for the passed VRML Coordinate node. Everything
  // is done here - there are no actions based upon later events.

  public void initialize() {

    // Take copies of all the fields for this node

    SFNode geoOrigin   = (SFNode) getField( "geoOrigin" );
    MFString geoSystem = (MFString) getField( "geoSystem" );
    MFString point     = (MFString) getField( "point" );
    SFNode coordinate  = (SFNode) getField( "coordinate" );
    boolean debug      = ((SFBool) getField( "debug" )).getValue();

    // Okay, let's initialise the GeoVRML utility class
    // These classes should be installed on the user's system and in
    // their CLASSPATH. If they are not, then we can't do anything!

    GeoVRML geovrml;
    try {
      geovrml = new GeoVRML();
    } catch ( NoClassDefFoundError e ) {
      System.out.println( "GeoTransform classes not installed in CLASSPATH!" );
      return;
    }

    geovrml.setOrigin( geoOrigin );
    // geovrml.scaleFactor = 1000000.0;

    // Now convert the point array into an array of
    // geocentric coordinates

    Gcc_Coord_3d gcc[] = geovrml.getCoords( point, geoSystem );

    // Put the array that we has just read in into a static array
    // of floats that can be passed to the Coordinate node.

    int size = gcc.length, j = 0;
    float vrml_point[] = new float[size*3];

    for ( int i = 0; i < size; i++ ) {
      vrml_point[j++] = (float) gcc[i].x;
      vrml_point[j++] = (float) gcc[i].y;
      vrml_point[j++] = (float) gcc[i].z;

      if ( debug ) 
	System.out.println( "Coord " + i + ": " + vrml_point[j-3] + ", "
			    + vrml_point[j-2] + ", " + vrml_point[j-1] );
    }

    // Now let's make the coords field of our Coordinate node 
    // equal to the list of coordinates that we have just built

    MFVec3f coord_point = (MFVec3f) ((Node)
			  coordinate.getValue()).getExposedField( "point" );
    coord_point.setValue( size*3, vrml_point );
    
  }

}

// EOF: GeoCoordinate.java
