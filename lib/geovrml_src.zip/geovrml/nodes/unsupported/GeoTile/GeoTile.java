//
//  GlobalRefCount.java by Kiril Vidimce
//  (c) SRI International, 1998. Menlo Park, CA 94025.
//
//  $Id: GeoTile.java,v 1.1.1.1 2000/06/15 16:49:27 reddy Exp $
//

import vrml.*;
import vrml.field.*;
import vrml.node.*;

import java.lang.*;
import java.util.*; 

public class GeoTile extends Script 
{
  ///////////////////////////////////////////////////////////////////////
  //
  // GeoTile's fields and eventOuts
  //
  private MFString terrainURL;                    // field
  private MFString terrainName;                   // field
  private MFString featureURL;                    // field
  private MFString featureName;                   // field

  private MFNode   chooserChildren_changed;       // eventOut

  ///////////////////////////////////////////////////////////////////////
  //
  // GlobalState's fields and eventOuts
  //
  private static MFString allTerrains;            // field
  private static MFString allTerrains_changed;    // eventOut

  private static MFString allFeatures;            // field
  private static MFString allFeatures_changed;    // eventOut

  private static SFString whichTerrain;           // field
  private static SFString whichTerrain_changed;   // eventOut

  private static MFString whichFeatures;          // field
  private static MFString whichFeatures_changed;  // eventOut

  private static MFNode   children;               // eventOut
  private static MFNode   addChildren;            // eventOut
  private static MFNode   removeChildren;         // eventOut

  ///////////////////////////////////////////////////////////////////////
  //
  // Internal state variables
  private boolean debug = true;                   // field

  // first denotes whether this is the first instantiation of the object.
  // It will be assumed that the first instantiation comes from the 
  // GlobalState PROTO which will have a Group node DEF'ed Root. This is
  // where all the feature data from the GeoTile nodes will be stored into.
  private static boolean first = true;

  // This is the pointer to the first instance of this script which also
  // handles the hash tables for the url's: i.e, their reference count and
  // position within the Root Group node
  private static GeoTile state = null;

  // These four hash tables are used for implementing:
  //
  //  fnameRefCount: 
  //     The reference count mechanism for feature url's.
  //     Since the features are associated with multiple tiles, we must
  //     provide reference counting mechanism to prevent multiple loads
  //     of the same feature.
  //
  //  floadNameRefCount:
  //     The reference count mechanism for loaded feature url's.
  //     We also must keep a separate reference count for the purpose
  //     of creating a list of available features. Note that this is
  //     different than fnameRefCount which keeps track of features
  //     that are part of the current VRML scene graph!
  //
  //  fnameInline:
  //     For fast lookup of the Inline node that loads the feature.
  //
  //  fnameURL:
  //     For fast lookup of the URL of a given feature. This is used for
  //     loading features based on a received event in the GlobalState's 
  //     whichFeatures field.
  //
  //  See also: pushFeature(), popFeature(), updateAllFeatures()
  //
  private static Hashtable fnameRefCount     = new Hashtable();
  private static Hashtable floadNameRefCount = new Hashtable();
  private static Hashtable fnameInline       = new Hashtable();
  private static Hashtable fnameURL          = new Hashtable();

  // This hash table is used for implementing the reference count mechanism
  // for terrains. It is similar in nature as floadNameRefCount and is used
  // for building a list of currently available terrains (i.e. GlobalState's
  // allTerrains field).
  //
  // See also: pushTerrain(), popTerrain(), updateAllTerrains()
  //
  private static Hashtable tloadNameRefCount = new Hashtable();

  // This holds a pointer to all the GeoTile scripts (100 should be a good 
  // estimate of the number of GeoTile's present at a given time).
  // It is necessary to have the pointer to all the GeoTile scripts for the
  // purpose of notifying the GeoTile's to change to a different terrain 
  // whenever the whichTerrain field changes in the GlobalState PROTO
  private static Vector geoTiles = new Vector(100);

  // A pointer to the browser
  private static Browser browser = null;

  // For debugging purposes: className stores the name of the current
  // class (this is necessary since this class as used both as a script class
  // for the GeoTile and the GlobalState node. 
  private String className;

  // globalState denots whether this script is used within a GlobalState node
  // or a GeoTile node
  boolean globalState = false;

  ///////////////////////////////////////////////////////////////////////////
  //
  // GlobalState&GeoTile.GlobalState&GeoTile()
  //
  // Constructor
  //
  GeoTile()
  {
    //initClass();
  }

  public void initClass()
  {
    ///String functName = null;

    browser = getBrowser();
    if (browser == null)
      System.out.println("Could not get the browser");

    // check if this is a GlobalState or a GeoTile
    globalState = ((SFBool) getField("globalState")).getValue();
  
    // if this is a global state and is the first instantiation of it,
    // store a pointer to this node
    // if (globalState && first)
    if (first && globalState)
    {
      // store a pointer to the GlobalState script
      state = this;

      // debug
      ///className = new String("GlobalState");
      ///functName = new String("GlobalState");
      ///printDebug(functName, "global state created");
    }
    else
    {
      // debug
      ///className = new String("GeoTile");
      ///functName = new String("GeoTile");

      geoTiles.addElement(this);
    }

    // debug
    ///printDebug(functName, "begin");
    ///printDebug(functName, "end");
  }

  ///////////////////////////////////////////////////////////////////////////
  //
  // Prints the name of the class, the name of the function and the action
  // message
  //
  private void printDebug(String functName, String action)
  {
    if (debug)
      System.out.println(className + "." + functName + "(): " + action);
  }

  ///////////////////////////////////////////////////////////////////////////
  //
  // GlobalState&GeoTile.initialize()
  //
  // Creates pointers to the Script's (both GlobalState and GeoTile) fields 
  // and event outs.
  //
  public void initialize()
  {
    initClass();

    // debug
    ///String functName = new String("initialize");
    ///printDebug(functName, "begin");

    // first-time initialization: grab a pointer to the globalChildren_changed 
    // eventOut which is routed to the Group node in the top-level 
    // GlobalRefCount node
    // if (globalState && first)
    if (globalState && first)
    {
      ///printDebug(functName, "1");
      browser = getBrowser();
      ///printDebug(functName, "2");

      allTerrains           = (MFString) getField("allTerrains");
      allTerrains_changed   = (MFString) getEventOut("allTerrains_changed");
 
      ///printDebug(functName, "3");
      allFeatures           = (MFString) getField("allFeatures");
      allFeatures_changed   = (MFString) getEventOut("allFeatures_changed");

      ///printDebug(functName, "4");
      whichTerrain          = (SFString) getField("whichTerrain");
      whichTerrain_changed  = (SFString) getEventOut("whichTerrain_changed");

      ///printDebug(functName, "5");
      whichFeatures         = (MFString) getField("whichFeatures");
      whichFeatures_changed = (MFString) getEventOut("whichFeatures_changed");

      ///printDebug(functName, "6");
      children              = (MFNode)   getEventOut("children");
      addChildren           = (MFNode)   getEventOut("addChildren");
      removeChildren        = (MFNode)   getEventOut("removeChildren");

      // done with first-time initialization
      first = false;
    }
    else
    {
      terrainURL            = (MFString) getField("terrainURL");
      terrainName           = (MFString) getField("terrainName");
      featureURL            = (MFString) getField("featureURL");
      featureName           = (MFString) getField("featureName");

      chooserChildren_changed = (MFNode) getEventOut("chooserChildren_changed");

      // add the terrains for this GeoTile into the list of terrains
      if (addTerrains())
      {
        // if there are new terrains, update the allTerrains field 
        updateAllTerrains();
      }
      // load the terrain tile for this GeoTile
      loadTerrain();

      // add the features reference by this tile
      if (addFeatures())
      {
        // if there are new features, update the allFeatures field 
        updateAllFeatures();
      }
      // load the feature tile for this GeoTile
      loadFeatures();
    }
    debug = ((SFBool) getField("debug")).getValue();

    // debug
    ///printDebug(functName, "end");
  }

  ///////////////////////////////////////////////////////////////////////////
  //
  // GlobalState&GeoTile.pushFeature()
  //
  // this is called when the browser deletes the script (presumably when
  // the PROTO is unloaded)
  //
  public void shutdown()
  {
    // debug
    ///String functName = new String("shutdown");
    ///printDebug(functName, "begin");

    if (state == this)
    {
      ///printDebug(functName, "destroying the global state");
    }
    else
    {
      // This is a GeoTile script: remove it from the list of GeoTile's
      geoTiles.removeElement(this);
 
      // Decrease the reference count for the terrains specified in this
      // GeoTile. If the reference count for any of them reaches 0, the
      // terrain gets removed from the hash table.
      //
      // removeTerrains() returns true if the terrain should be removed
      // from the list of available terrains (i.e., when the refCount for
      // this terrain reached 0)
      if (removeTerrains())
        updateAllTerrains();

      // See above for terrains
      if (removeFeatures())
        updateAllFeatures();
    }

    // debug
    ///printDebug(functName, "end");
  }

  ///////////////////////////////////////////////////////////////////////////
  //
  // GeoTile.pushFeature()
  //
  // pushFeature() and popFeature() serve as "stack" functions that implement
  // the reference count mechanism for currently loaded (in memory) features.
  // These methods also maintain the fnameURL hash table that enables fast
  // lookup of URL's for a given feature 
  //
  // See also: popFeature()
  //
  public int pushFeature(int f)
  {
    // debug
    ///String functName = new String("pushFeature");
    ///printDebug(functName, "begin");

    String name = featureName.get1Value(f);
    String url  = featureURL.get1Value(f);

    // if this url hasn't been loaded before, the refCount becomes 1
    int refCount = 1;

    // attempt to fetch the refCount for this url from the hash table
    Integer RefCount = (Integer) fnameRefCount.remove(name);

    // if the url is in the hash table, just increase the refCount
    if (RefCount != null)
    {
      refCount = RefCount.intValue() + 1;

      // debug
      ///printDebug(functName, "Feature " + name + " already loaded: " + refCount);
    }
    else
    {
      // if it's the first time, add the url into the fnameURL hash table
      fnameURL.put(name, url);
    }

    // else, insert it into the hash table for the first time with refCount 1
    fnameRefCount.put(name, new Integer(refCount));

    // debug
    ///printDebug(functName, "end");

    return refCount;
  }

  /////////////////////////////////////////////////////////////////////////
  //
  // GeoTile.popFeature()
  //
  // See also: pushFeature()
  //
  public int popFeature(int f)
  {
    // debug
    ///String functName = new String("popFeature");
    ///printDebug(functName, "begin");

    String name = featureName.get1Value(f);

    // attempt to retrieve the refCount value from the hash table;
    // if the attempt is unsuccessfull, report an error.
    Integer RefCount = (Integer) fnameRefCount.remove(name);
    if (RefCount == null)
    {
      ///printDebug(functName, "Error: unloading a terrain not loaded before");
      return -1;
    }

    // decrease the reference count
    int refCount = RefCount.intValue() - 1;

    if (refCount == 0)
    {
      // if the reference count goes to 0, remove the url
      fnameURL.remove(name);
    }
    else
    {
      // else, return it back into the hash table
      fnameRefCount.put(name, new Integer(refCount));
    }

    // debug
    ///printDebug(functName, "end");

    return refCount;
  }  

  public int getFeatureRefCount(String name)
  {
    // debug
    ///String functName = new String("getFeatureRefCount");
    ///printDebug(functName, "begin");

    // debug
    ///printDebug(functName, "end");

    // attempt to fetch the refCount for this url from the hash table
    return ((Integer) floadNameRefCount.get(name)).intValue();
  }

  ///////////////////////////////////////////////////////////////////////////
  public int pushLoadFeature(String name)
  {
    // debug
    ///String functName = new String("pushLoadFeature");
    ///printDebug(functName, "begin");

    // if this url hasn't been loaded before, the refCount becomes 1
    int refCount = 1;

    // attempt to fetch the refCount for this url from the hash table
    Integer RefCount = (Integer) floadNameRefCount.remove(name);

    // if the url is in the hash table, just increase the refCount
    if (RefCount != null)
    {
      refCount = RefCount.intValue() + 1;

      // debug
      ///printDebug(functName, "Feature " + name + " already loaded: " + refCount);
    }
 
    floadNameRefCount.put(name, new Integer(refCount));

    // debug
    ///printDebug(functName, "end");

    return refCount;
  }

  ///////////////////////////////////////////////////////////////////////////
  public int popLoadFeature(String name)
  {
    // debug
    ///String functName = new String("popLoadFeature");
    ///printDebug(functName, "begin");

    // attempt to retrieve the refCount value from the hash table;
    // if the attempt is unsuccessfull, report an error.
    Integer RefCount = (Integer) floadNameRefCount.remove(name);
    if (RefCount == null)
    {
      ///printDebug(functName, "Error: unloading a feature not loaded before");
      return -1;
    }

    // decrease the reference count
    int refCount = RefCount.intValue() - 1;

    // XXX -- not implemented!
    // if (refCount == 0)

    // debug
    ///printDebug(functName, "end");

    return refCount;
  }

  /////////////////////////////////////////////////////////////////////////
  //
  //
  public int pushTerrain(int t)
  {
    // debug
    ///String functName = new String("pushTerrain");
    ///printDebug(functName, "begin");

    String name = terrainName.get1Value(t);

    // if this url hasn't been loaded before, the refCount becomes 1
    int refCount = 1;

    // attempt to fetch the refCount for this url from the hash table
    Integer RefCount = (Integer) tloadNameRefCount.remove(name);

    // if the url is in the hash table, just increase the refCount
    if (RefCount != null)
    {
      refCount = RefCount.intValue() + 1;

      // debug
      ///printDebug(functName, "Terrain " + name + " already loaded: " + refCount);
    }
    // else, insert it into the hash table for the first time with refCount 1
    tloadNameRefCount.put(name, new Integer(refCount));

    // debug
    ///printDebug(functName, "end");

    return refCount;
  }

  /////////////////////////////////////////////////////////////////////////
  //
  // popTerrain()
  // 
  // See also: pushTerrain()
  //
  public int popTerrain(int t)
  {
    // debug
    ///String functName = new String("popTerrain");
    ///printDebug(functName, "begin");

    String name = terrainName.get1Value(t);
    
    // attempt to retrieve the refCount value from the hash table;
    // if the attempt is unsuccessfull, report an error.
    Integer RefCount = (Integer) tloadNameRefCount.remove(name);
    if (RefCount == null)
    {
      ///printDebug(functName, "Error: unloading a terrain not loaded before");
      return -1;
    }

    // decrease the reference count
    int refCount = RefCount.intValue() - 1;

    // if the reference count is not zero, return it back into the hash table
    if (refCount != 0)
    {
      tloadNameRefCount.put(name, new Integer(refCount));
    }

    // debug
    ///printDebug(functName, "end");

    return refCount;
  }

  //////////////////////////////////////////////////////////////////////////
  //
  // setTileURL() creates an Inline node that loads the terrain tile for  
  // this GeoTile
  //
  public void setTileURL(String url)
  {
    // debug
    ///String functName = new String("setTileURL");
    ///printDebug(functName, "begin");

    ///printDebug(functName, "Loading " + url);

    BaseNode[] bnode;
    try
    {
      bnode = browser.createVrmlFromString("Inline {" +
                                           "  url [\"" + url + "\"]" +
                                           "}");
    }
    catch (InvalidVRMLSyntaxException e)
    {
      // debug
      ///printDebug(functName, "can not create Inline node for " + url);
      return;
    }
    // set the Inline node to be the new (sole) child of the terrain Group
    chooserChildren_changed.setValue(bnode);

    // debug
    ///printDebug(functName, "end");
  }

  //////////////////////////////////////////////////////////////////////////
  //
  //
  public void unsetTileURL()
  {
    // debug
    ///String functName = new String("unsetTileURL");
    ///printDebug(functName, "begin");

    // insert an empty MFNode field into the Terrain group node
    chooserChildren_changed.setValue(new MFNode());
  
    // debug
    ///printDebug(functName, "end");
  }

  /////////////////////////////////////////////////////////////////////////
  //
  //
  public boolean addTerrains()
  {
    // debug
    ///String functName = new String("addTerrains");
    ///printDebug(functName, "begin");

    boolean newTerrains = false;
    for (int t = 0; t < terrainName.getSize(); t++)
    {
      // if the reference count is 1, this terrain is a new one
      if (pushTerrain(t) == 1)
        newTerrains = true; 
    }

    // debug
    ///printDebug(functName, "end");

    return newTerrains;
  }

  /////////////////////////////////////////////////////////////////////////
  //
  // removeTerrains() decreases the reference count for each of the terrains
  // formerly available in the terrainName field.
  //
  // See also: addTerrains()
  //
  public boolean removeTerrains()
  {
    // debug
    ///String functName = new String("removeTerrains");
    ///printDebug(functName, "begin");

    boolean updateTerrains = false;
    for (int t = 0; t < terrainName.getSize(); t++)
    {
      if (popTerrain(t) == 0)
        updateTerrains = true;
    }

    // debug
    ///printDebug(functName, "end");

    return updateTerrains;
  }

  /////////////////////////////////////////////////////////////////////////
  //
  // updateAllTerrains() updates the list of all available terrains
  // and updated the value of the GlobalState's allTerrains field 
  // accordingly
  //
  public void updateAllTerrains()
  {
    // debug
    ///String functName = new String("updateAllTerrains");
    ///printDebug(functName, "begin");

    String[] newAllTerrains = new String[tloadNameRefCount.size()];
    ///printDebug(functName, "1");
    int t = 0;
    for (Enumeration e = tloadNameRefCount.keys(); e.hasMoreElements(); t++)
    {
      ///printDebug(functName, "2");
      newAllTerrains[t] = (String) e.nextElement();
    }

    ///printDebug(functName, "3");
    allTerrains.setValue(newAllTerrains);
    ///printDebug(functName, "4");
    allTerrains_changed.setValue(newAllTerrains);

    // debug
    ///printDebug(functName, "end");
  }

  /////////////////////////////////////////////////////////////////////////
  //
  // loadTerrain() is called either when initializing the GeoTile node
  // or when the terrainName gets changed. loadTerrain() uses the
  // whichTerrain field to determine what terrain tile needs to be loaded.
  // It does that by traversing the terrain names available for this
  // tile and comparing them to the name of the terrain stored in whichTerrain.
  // Once found, the terrain tile loads. If the terrain specified by the 
  // GlobalState is not found, loadTerrain() defaults to the first terrain 
  // specified in the terrainURL field
  //
  public void loadTerrain()
  {
    // debug
    ///String functName = new String("loadTerrain");
    ///printDebug(functName, "begin");

    String which = whichTerrain.getValue();
    if (which.length() == 0)
    {
      // "" means remove terrain
      // unsetTileURL();
      // load the default (first) terrain
      setTileURL(terrainURL.get1Value(0));
    }
    else 
    {
      // check if the terrain is available for this tile
      boolean found = false;
      for (int t = 0; t < terrainName.getSize(); t++)
      {
        if (terrainName.get1Value(t).equals(which))
        { 
          // terrain found, change the url of the Inline node to load the tile
          setTileURL(terrainURL.get1Value(t));
          found = true;
          break;
        }
      }
  
      // if terrain not found, load the first URL provided in the GeoTile
      if (!found && terrainURL.getSize() > 0)
        setTileURL(terrainURL.get1Value(0));
    }
    
    // debug
    ///printDebug(functName, "end");
  }

  public boolean addFeatures()
  {
    // debug
    ///String functName = new String("addFeatures");
    ///printDebug(functName, "begin");

    boolean newFeatures = false;
    for (int f = 0; f < featureName.getSize(); f++)
    {
      // if the reference count is 1, this feature is a new one
      if (pushFeature(f) == 1)
        newFeatures = true;
    }
  
    // debug
    ///printDebug(functName, "end");

    return newFeatures;
  }

  public boolean removeFeatures()
  {
    // debug
    ///String functName = new String("removeFeatures");
    ///printDebug(functName, "begin");

    BaseNode[] removeNodes = new BaseNode[whichFeatures.getSize()];
    int removeNodesNum = 0;

    boolean updateFeatures = false;
    for (int f = 0; f < featureName.getSize(); f++)
    {
      if (popFeature(f) == 0)
      {
        removeNodes[removeNodesNum++] = 
          (BaseNode) fnameInline.remove(featureName.get1Value(f));
        updateFeatures = true;
      }
    }

    if (removeNodesNum > 0)
      removeChildren.setValue(removeNodesNum, removeNodes);

    // debug
    ///printDebug(functName, "end");

    return updateFeatures;
  }

  public void updateAllFeatures()
  {
    // debug
    ///String functName = new String("updateAllFeatures");
    ///printDebug(functName, "begin");

    // update the list of currently available features in the GlobalState node
    String []newAllFeatures = new String[fnameRefCount.size()];
    int f = 0;
    for (Enumeration e = fnameRefCount.keys(); e.hasMoreElements(); f++)
    {
      newAllFeatures[f] = (String) e.nextElement();
    }
    allFeatures.setValue(newAllFeatures);
    allFeatures_changed.setValue(newAllFeatures);

    // debug
    ///printDebug(functName, "end");
  }

  public void loadFeatures()
  {
    // debug
    ///String functName = new String("loadFeatures");
    ///printDebug(functName, "begin");

    int wfSize = whichFeatures.getSize();
    ///printDebug(functName, "features selected: " + wfSize);
    if (wfSize > 0)
    {
      // addValue() is buggy; instead of using addValue(), we'll create 
      // BaseNodes with enough memory to hold every feature URL and then 
      // pass only the ones that we really need to load
      // BaseNode[] addNodes    = new BaseNode[featureURL.getSize()];
      BaseNode[] addNodes = new BaseNode[wfSize];

      int addNodesNum = 0;
      for (int w = 0; w < wfSize; w++)
      {
        String name = (String) whichFeatures.get1Value(w);
        String url  = (String) fnameURL.get(name);

        if (url != null)
        {
          BaseNode[] inline = null;
          if (getFeatureRefCount(name) == 1)
          {
            try
            {
              // debug
              ///printDebug(functName, "Loading " + url);
       
              inline = browser.createVrmlFromString("Inline {" +
                                                    "  url [\"" + url + "\"]" +
                                                    "}");
       
              // put the Inline node pointer in the Inline hash table
              fnameInline.put(name, inline[0]);

              pushLoadFeature(name);
            }
            catch (InvalidVRMLSyntaxException e)
            {
              // debug
              ///printDebug(functName, "can not create Inline node");
              ///printDebug(functName, "end");
              return;
            }

            addNodes[addNodesNum++] = inline[0];
          }
        }
        else 
        {
          // debug
          ///printDebug(functName, "The url for " + " does not exist!");
          ///printDebug(functName, "end");
          return;
        }
      }

      addChildren.setValue(addNodes);
      // addChildren.setValue(addNodesNum, addNodes);
    }
    else
    {
      // debug
      ///printDebug(functName, "no features");
    }

    // debug
    ///printDebug(functName, "end");
  }
      
  public void unloadFeatures()
  {
    // debug
    ///String functName = new String("unloadFeatures");
    ///printDebug(functName, "begin");

    // debug
    ///printDebug(functName, "end");
  }

  public void updateFeatures(ConstMFString newWhichFeatures) 
  {
    // debug
    ///String functName = new String("updateFeatures");
    ///printDebug(functName, "begin");

    BaseNode[] removeNodes = new BaseNode[whichFeatures.getSize()];
    int removeNodesNum = 0;
    for (int w = 0; w < whichFeatures.getSize(); w++)
    {
      String wf = whichFeatures.get1Value(w);
      boolean staysLoaded = false;
      for (int nw = 0; nw < newWhichFeatures.getSize(); nw++)
      {
        if (newWhichFeatures.get1Value(nw).equals(wf))
        {
          staysLoaded = true;
          break;
        }
      }

      if (!staysLoaded)
      {
        popLoadFeature(wf);
        removeNodes[removeNodesNum++] = (BaseNode) fnameInline.remove(wf);
      }
    }

    if (removeNodesNum > 0)
      removeChildren.setValue(removeNodesNum, removeNodes);

    // debug
    ///printDebug(functName, "end");
  }

  ///////////////////////////////////////////////////////////////////////////
  public void processEvent(Event e) 
  {
    ///String functName = new String("processEvent");
    ///printDebug(functName, "begin");

    String eventName = e.getName();
    ///printDebug(functName, "processing " + eventName);

    if (eventName.equals("set_whichTerrain"))
    {
      ConstSFString newWhichTerrain = (ConstSFString) e.getValue();
      whichTerrain.setValue(newWhichTerrain);
      whichTerrain_changed.setValue(newWhichTerrain);

      // load the new terrain tile
      loadTerrain();
    }
    else if (eventName.equals("set_whichFeatures"))
    {
      ConstMFString newWhichFeatures = (ConstMFString) e.getValue();

      updateFeatures(newWhichFeatures);
      whichFeatures.setValue(newWhichFeatures);
      whichFeatures_changed.setValue(newWhichFeatures);
      loadFeatures();
    }

    ///printDebug(functName, "end");
  }
}
