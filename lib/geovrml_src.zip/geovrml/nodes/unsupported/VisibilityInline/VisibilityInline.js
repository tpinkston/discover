/* See VisibilityInline.java for documentation - M.Reddy 1998 */

function nodesLoaded( new_nodes, ts ) {
  group.addChildren = new_nodes;
  children = group.addChildren;
  load = true;
  load_changed = true;
}

function initialize() {
  children = group.children;
  geourl_changed = geourl;
  load_changed = load;
  bboxCenter_changed = bboxCenter;
  bboxSize_changed = bboxSize;
  if ( load == true ) {
    Browser.createVrmlFromURL( geourl, myself, 'nodesLoaded' );
  }
}

function loadUrl() {
  if ( load == false ) {
    Browser.createVrmlFromURL( geourl, myself, 'nodesLoaded' );
    if ( debug ) print( 'Loading '+geourl[0] );
  }
}

function unloadUrl() {
  if ( load == true ) {
    group.removeChildren = group.children;
    children = empty_node;
    load = false;
    load_changed = false;
    if ( debug ) print( 'Unloading '+geourl[0] );
  }
}

function shutdown() {
  unloadUrl();
}

function set_load( new_load, ts ) {
  if ( load != new_load ) {
    if ( new_load == true ) {
      loadUrl();
    } else {
      unloadUrl();
    }
  }
}

function set_url( new_url, ts ) {
  if ( load == true ) {
    unloadUrl();
    geourl = new_url;
    loadUrl();
  } else {
    geourl = new_url;
  }
  geourl_changed = new_url;
}

function set_bboxCenter( new_center, ts ) {
  VizSensor.center = new_center;
  bboxCenter = new_center;
  bboxCenter_changed = new_center;
}

function set_bboxSize( new_size, ts ) {
  VizSensor.size = new_size;
  bboxSize = new_size;
  bboxSize_changed = new_size;
}

function set_value( value ) { 
  if ( bboxSize[0] == -1 )
    value_changed = 0;
  else {
    if ( value == false )
      value_changed = -1; 
    else
      value_changed = 0;
  }
  if ( debug ) print( 'Set Switch to '+value_changed+' for '+geourl[0] );
}
