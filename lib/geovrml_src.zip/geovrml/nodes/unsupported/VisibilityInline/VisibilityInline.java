//
//  VisibilityInline.java by Martin Reddy. SRI International, 1998.
//
//  This class implements a new Inline node for VRML. It aims to provide
//  the same basic functionality as the built-in Inline node, but offers
//  control over when the file to be inlined should be loaded, both
//  statically (in the VRML code) and dynamically (via events passed into
//  the node). Any loaded nodes are automatically culled from the scene
//  graph when they are not visible.  Functionality is also available to
//  unload an already inlined file. In addition, the VisibilityInline node
//  exposes the scene graph for the inlined file so that this can be
//  accessed by APIs such as the EAI.
//
//  $Id: VisibilityInline.java,v 1.1.1.1 2000/06/15 16:49:27 reddy Exp $
//

import vrml.*;
import vrml.field.*;
import vrml.node.*;

public class VisibilityInline extends Script {
  
  // Java versions of the Script's fields and eventOuts
   
  private SFNode   group;              // field
  private SFNode   VizSensor;          // field
  private MFNode   children;           // eventOut
  private MFString geourl_changed;     // eventOut
  private SFBool   load_changed;       // eventOut
  private SFVec3f  bboxCenter;         // field
  private SFVec3f  bboxCenter_changed; // eventOut
  private SFVec3f  bboxSize;           // field
  private SFVec3f  bboxSize_changed;   // eventOut
  private SFInt32  value_changed;      // eventOut
  private MFNode   empty_node;         // field
  private MFString empty_string;       // field

  // Internal state variables

  private String[] geourl;             // field
  private boolean  load;               // field
  private boolean  debug;              // field
  private Browser  browser;

  // The initiate_load() method is used to load the scene
  // for the VisibilityInline. It uses the Browser method
  // createVrmlFromURL to perform this. Once the scene has
  // been loaded, a nodesLoaded eventIn is sent to the
  // processEvent() method below.

  public void initiate_load() {
    try {
      browser.createVrmlFromURL( geourl, this, "nodesLoaded" );
    } catch ( InvalidVRMLSyntaxException e ) {
      System.out.println( "Couldn't perform createVrmlFromURL" );
      return;
    }
    if ( debug ) System.out.println( "Loading " + geourl[0] );
  }

  // The initialize method is called when the Node is first loaded.
  // Here we grab copies of any necessary fields/eventIn/eventOuts
  // and fire off initial values for the eventOuts.

  public void initialize() {

    // Take copies of all the fields for this node

    group              = (SFNode) getField( "group" );
    children           = (MFNode) getEventOut( "children" );
    VizSensor          = (SFNode) getField( "VizSensor" );
    MFString geo_url   = (MFString) getField( "geourl" );
    geourl = new String[geo_url.getSize()];
    geo_url.getValue( geourl );
    geourl_changed     = (MFString) getEventOut( "geourl_changed" );
    load               = ((SFBool) getField( "load" )).getValue();
    load_changed       = (SFBool) getEventOut( "load_changed" );
    bboxCenter         = (SFVec3f) getField( "bboxCenter" );
    bboxCenter_changed = (SFVec3f) getEventOut( "bboxCenter_changed" );
    bboxSize           = (SFVec3f) getField( "bboxSize" );
    bboxSize_changed   = (SFVec3f) getEventOut( "bboxSize_changed" );
    value_changed      = (SFInt32) getEventOut( "value_changed" );
    empty_node         = (MFNode) getField( "empty_node" );
    empty_string       = (MFString) getField( "empty_string" );
    debug              = ((SFBool) getField( "debug" )).getValue();

    // Grab the Browser object

    browser = getBrowser();

    // Initialise any eventOuts to default values

    children.setValue( (ConstMFNode) ((Node) group.getValue()).getEventOut(
		       "children" ) );
    geourl_changed.setValue( geourl );
    load_changed.setValue( load );
    bboxCenter_changed.setValue( bboxCenter );
    bboxSize_changed.setValue( bboxSize );
    if ( load == true ) initiate_load();
  }

  // Load the inline scene, if not already loaded

  public void loadUrl() {
    if ( load == false ) initiate_load();
  }

  // Remove the current inline nodes from the scene, if loaded

  public void unloadUrl() {
    if ( load == true ) {
      MFNode rc = (MFNode) ((Node) group.getValue()).getEventIn(
		   "removeChildren" );
      rc.setValue( (ConstMFNode) ((Node) group.getValue()).getEventOut(
		   "children") );
      children.setValue( empty_node );
      load = false;
      load_changed.setValue( false );
      if ( debug ) System.out.println( "Unloading "+geourl[0] );
    }
  }

  // The shutdown method is called when this object is destroyed

  public void shutdown() {
    unloadUrl();
  }

  // Handle all of the eventIn's that we support....

  public void processEvent( Event e ) {
    String event_name = e.getName();

    // The set_load eventIn is used to load or unload the nodes
    // for the Inline from the scene graph. Checks are made so
    // that we don't try to load a file if it is already loaded
    // and we don't try to unload a file if there is no file loaded
    
    if ( event_name.equals( "set_load" ) ) {
      boolean new_load = ((ConstSFBool) e.getValue()).getValue();
      
      if ( load != new_load ) {
	if ( new_load == true ) {
	  loadUrl();
	} else {
	  unloadUrl();
	}
      }
      
      // The set_url eventIn is used to change the url of the 
      // Inline node and to cause this url to be loaded if the
      // current state of the node is load == true.
      
    } else if ( event_name.equals( "set_url" ) ) {
      ConstMFString mfs = (ConstMFString) e.getValue();
      String[] new_url = new String[mfs.getSize()];
      mfs.getValue( new_url );
      
      if ( load == true ) {
	unloadUrl();
	geourl = new_url;
	loadUrl();
      } else {
	geourl = new_url;
      }
      geourl_changed.setValue( new_url );
      
      // The set_bboxCenter eventIn is used to change the bounding
      // box center point that is used for the VisiblitySensor
      
    } else if ( event_name.equals( "set_bboxCenter" ) ) {
      float[] new_center = new float[3];
      ((ConstSFVec3f) e.getValue()).getValue( new_center );
      
      SFVec3f nc = (SFVec3f) ((Node) VizSensor.getValue()).getEventIn(
                   "center" );
      nc.setValue( new_center );
      bboxCenter.setValue( new_center );
      bboxCenter_changed.setValue( new_center );
      
      // The set_bboxSize eventIn is used to change the bounding
      // box dimensions that are used for the VisiblitySensor
      
    } else if ( event_name.equals( "set_bboxSize" ) ) {
      float[] new_size = new float[3];
      ((ConstSFVec3f) e.getValue()).getValue( new_size );
      
      SFVec3f ns = (SFVec3f) ((Node) VizSensor.getValue()).getEventIn(
                    "size" );
      ns.setValue( new_size );
      bboxSize.setValue( new_size );
      bboxSize_changed.setValue( new_size );
      
      // The set_value eventIn is used to change the whichChoice
      // field of the Switch node to switch in or out any loaded
      // nodes when they are not visible. We switch the loaded
      // nodes out only if a valid bounding box has been specified.
      
    } else if ( event_name.equals( "set_value" ) ) {
      boolean new_value = ((ConstSFBool) e.getValue()).getValue();
      int     new_setting = 0;
      
      if ( bboxSize.getX() != -1 && new_value == false )
	new_setting = -1;
      
      value_changed.setValue( new_setting );
      
      if ( debug ) 
	System.out.println( "Set Switch to "+new_setting+" for "+geourl[0] );
      
      // The nodesLoaded event is only used within this object.
      // It used called by createVrmlFromURL when it has completed
      // the loading of the Inline url file
      
    } else if ( event_name.equals( "nodesLoaded" ) ) {
      ConstMFNode new_nodes = (ConstMFNode) e.getValue();

      MFNode ac = (MFNode) ((Node) group.getValue()).getEventIn( 
		  "addChildren" );
      ac.setValue( new_nodes );

      Node[] nodes = new Node[new_nodes.getSize()];
      new_nodes.getValue( nodes );
      children.setValue( nodes );

      load = true;
      load_changed.setValue( true );
    }
    
    
  }
}

// EOF: VisibilityInline.java
