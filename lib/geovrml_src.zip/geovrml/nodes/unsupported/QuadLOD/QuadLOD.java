//
//  QuadLOD.java by Martin Reddy and Kiril Vidimce.
//
// (c) SRI International, 1998. Menlo Park, CA 94025.
//
//  This class implements a new LOD node for VRML called QuadLOD. This
//  aims to provide a specialised solution for supporting the large,
//  multi-resolution terrain grids. The node will switch the
//  representation of a feature based upon its distance from the
//  viewpoint. Only two levels of detail can be specified, however
//  arbitarily deep hierarchies can be produced by nesting several
//  QuadLOD nodes. The node works by displaying a single piece of
//  geometry by default. Then when the viewpoint nears this geometry
//  it is replaced by four alternative geometries. This is meant to
//  represent a single low resolution terrain tile that is then
//  subdivided into four higher resolution quadrants
//
//  $Id: QuadLOD.java,v 1.1.1.1 2000/06/15 16:49:27 reddy Exp $
//

import vrml.*;
import vrml.field.*;
import vrml.node.*;

public class QuadLOD extends Script {
   
  // Java versions of the Script's fields and eventOuts
   
  private MFNode  children;           // eventOut
  private SFNode  group;              // field
  private SFNode  prox_node;          // field
  private SFVec3f parentCenter;       // field
  private SFVec3f parentSize;         // field
  private SFBool  enabled_changed;    // eventOut
  private SFNode  switch_node;        // field

  // Internal state variables

  boolean value1 = false, value2 = false, value3 = false, value4 = false;
  boolean enabled = true;
  boolean done_bboxes = false;
  
  private boolean debug = true;
  
  QuadLOD() {
    if ( debug ) printDebug( "QuadLOD", "instantiated." );
  }
  
  ///////////////////////////////////////////////////////////////////////////
  //
  // Prints the name of the class, the name of the function and the action
  // message
  //
  private void printDebug(String functName, String action) {
    System.out.println( "QuadLOD." + functName + "(): " + action);
  }

  // The initialize method is called when the Node is first loaded.
  // Here we grab copies of any necessary fields/eventIn/eventOuts
  // and fire off initial values for the eventOuts.
  
  public void initialize() {

    String functName = new String("initialize");
    if ( debug ) printDebug( functName, "begin" );
    
    // Take copies of all the fields for this node
      
    children = (MFNode) getEventOut( "children" );
    group = (SFNode) getField( "group" );
    prox_node = (SFNode) getField( "prox_node" );
    parentCenter = (SFVec3f) getField( "parentCenter" );
    parentSize = (SFVec3f) getField( "parentSize" );
    
    enabled = ((SFBool) getField( "enabled" )).getValue();
    enabled_changed = (SFBool) getEventOut( "enabled_changed" );
    
    switch_node = (SFNode) getField( "switch_node" );
    value1 = ((SFBool) getField( "value1" )).getValue();
    value2 = ((SFBool) getField( "value2" )).getValue();
    value3 = ((SFBool) getField( "value3" )).getValue();
    value4 = ((SFBool) getField( "value4" )).getValue();

    // Initialise any eventOuts to default values

    children.setValue( (ConstMFNode) ((Node) group.getValue()).getEventOut( "children" ) );
    enabled_changed.setValue( enabled );

    if ( debug ) printDebug( functName, "end" );
  }

  // The flick_switch method sets the value of the switch node so that the
  // higher res children are only switched in when value1..value4 are true
  // (i.e. when the VisibilityInline node field load_changed is true for all
  // of the children).

  private void flick_switch() {
    String functName = new String( "flick_switch" );
    if ( debug ) printDebug( functName, "begin" );

    SFInt32 which_choice = (SFInt32) 
      ((Node) switch_node.getValue()).getEventIn( "whichChoice" );

    if ( value1 && value2 && value3 && value4 ) {
      // try { Thread.sleep(100); }
      // catch (InterruptedException ignored) {}
      which_choice.setValue( 1 );
    } else 
      which_choice.setValue( 0 );

    printDebug( functName, "end" );
  }

  // This is the method that processes all of the EventIns that we support

  public void processEvent( Event e ) {
    String functName = new String( "processEvent" );
    if ( debug ) printDebug( functName, "begin" );

    String event_name = e.getName();
    if ( debug ) printDebug( functName, "processing " + event_name );

    // The set_value<n> events are triggered when we want to change
    // the value of the load field inside a VisibilityInline
 
    if ( event_name.equals( "set_value1" ) ) {
      value1 = ((ConstSFBool) e.getValue()).getValue();
      flick_switch();
    } else if ( event_name.equals( "set_value2" ) ) {
      value2 = ((ConstSFBool) e.getValue()).getValue();
      flick_switch();
    } else if ( event_name.equals( "set_value3" ) ) {
      value3 = ((ConstSFBool) e.getValue()).getValue();
      flick_switch();
    } else if ( event_name.equals( "set_value4" ) ) {
      value4 = ((ConstSFBool) e.getValue()).getValue();
      flick_switch();
      
      // The set_enabled eventIn lets us disable or enable
      // the proximity sensor that controls the LOD switching

    } else if ( event_name.equals( "set_enabled" ) ) {

      boolean new_value = ((ConstSFBool) e.getValue()).getValue();

      if ( new_value != enabled ) {
	SFBool prox_enabled = (SFBool) 
	  ((Node) prox_node.getValue()).getEventIn( "enabled" );
	
	prox_enabled.setValue( new_value );
	enabled = new_value;
	enabled_changed.setValue( new_value );
      }
      
      // Output a warning to the Java Console if event not handled
      
    } else {
      if ( debug ) printDebug( functName, "Unknown Event: " + event_name );
    }

    if ( debug ) printDebug( functName, "end" );
  }

}

// EOF: QuadLOD.java
