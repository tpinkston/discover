//
//  QuadLODInline.java by Martin Reddy and Kiril Vidimce. 
//
//  (C) SRI International, 1998. Menlo Park, CA 94025.
//
//  This class implements a new Inline node for VRML. It aims to provide
//  the same basic functionality as the built-in Inline node, but offers
//  control over when the file to be inlined should be loaded, both
//  statically (in the VRML code) and dynamically (via events passed into
//  the node). Any loaded nodes are automatically culled from the scene
//  graph when they are not visible.  Functionality is also available to
//  unload an already inlined file. In addition, the VisibilityInline node
//  exposes the scene graph for the inlined file so that this can be
//  accessed by APIs such as the EAI.
//
//  This class is based upon the VisibilityInline class.
//
//  $Id: QuadLODInline.java,v 1.1.1.1 2000/06/15 16:49:27 reddy Exp $
//

import vrml.*;
import vrml.field.*;
import vrml.node.*;

public class QuadLODInline extends Script {
  
  // Java versions of the Script's fields and eventOuts
   
  private SFNode   group;              // field
  private SFNode   VizSensor;          // field
  private MFNode   children;           // eventOut
  private MFString geo_url;            // field
  private MFString geourl_changed;     // eventOut
  private SFBool   load_changed;       // eventOut
  private SFVec3f  bboxCenter;         // field
  private SFVec3f  bboxCenter_changed; // eventOut
  private SFVec3f  bboxSize;           // field
  private SFVec3f  bboxSize_changed;   // eventOut
  private SFInt32  value_changed;      // eventOut
  private MFNode   empty_node;         // field
  private MFString empty_string;       // field

  // Internal state variables

  private String[] geourl;             // field
  private boolean  load;               // field
  private boolean  debug;              // field
  private Browser  browser;

  private Node quadlod = null;

  // Cache-related stuff
  private static int cacheSize = 0;
  private static Cache cacheTiles = null;
  private static boolean cacheNode = false;
  private static boolean firstInstance = true;

  // The initiate_load() method is used to load the scene
  // for the VisibilityInline. It uses the Browser method
  // createVrmlFromURL to perform this. Once the scene has
  // been loaded, a nodesLoaded eventIn is sent to the
  // processEvent() method below.

  QuadLODInline() 
  { 
/*
    if (firstInstance)
    {
      System.out.println("Cache.begin");
      System.out.println("Cache.end");
    }
    else
    {
      System.out.println("QuadLODInline.begin");
      System.out.println("QuadLODInline.end");
    }
 */
  }

  public void initiate_load() 
  {
    ///System.out.println("QuadLODInline.initiate_load(): begin");

    if (geo_url.getSize() == 0)
    {
      ///System.out.println("Empty url. Not loading.");
      load = true;
      load_changed.setValue( true );
      return;
    }

    ConstMFNode tile = cacheTiles.get(geourl[0]);
    if (tile == null)
    {
      ///System.out.println("QuadLODInline.initiate_load(): tile not cached");
      try 
      {
        browser.createVrmlFromURL( geourl, this, "nodesLoaded" );
      } catch ( InvalidVRMLSyntaxException e ) 
      {
        ///System.out.println( "Couldn't perform createVrmlFromURL" );
        return;
      }
      ///if ( debug ) System.out.println( "Loading " + geourl[0] );
    }
    else
    {
      ///System.out.println("QuadLODInline.initiate_load(): tile cached");
      ///if ( debug ) System.out.println( "Using cached tile for " + geourl[0] );

      // Node[] nodes = new Node[tile.getSize()];
      // tile.getValue(nodes);

      MFNode ac = (MFNode) ((Node) group.getValue()).getExposedField("children");
      ac.setValue(tile);
      children.setValue(tile);
      load = true;
      load_changed.setValue( true );
    }
    ///System.out.println("QuadLODInline.initiate_load(): end");
  }

  // The initialize method is called when the Node is first loaded.
  // Here we grab copies of any necessary fields/eventIn/eventOuts
  // and fire off initial values for the eventOuts.

  public void initialize() 
  {
    // Grab the Browser object
    browser = this.getBrowser();

    cacheNode = ((SFBool) getField("cacheNode")).getValue();

    if (cacheNode)
    {
      ///System.out.println("Cache.created");
      cacheSize          = ((SFInt32) getField("cacheSize")).getValue();
      firstInstance      = false;

      cacheTiles = new Cache(cacheSize);
    }
    else
    {
      ///System.out.println("QuadLODInline.created");

      // Take copies of all the fields for this node
      group              = (SFNode) getField( "group" );
      children           = (MFNode) getEventOut( "children" );
      VizSensor          = (SFNode) getField( "VizSensor" );
      geo_url            = (MFString) getField( "geourl" );
      if (geo_url.getSize() != 0)
      {
        geourl = new String[geo_url.getSize()];
        geo_url.getValue( geourl );
      }
      geourl_changed     = (MFString) getEventOut( "geourl_changed" );
      load               = ((SFBool) getField( "load" )).getValue();
      load_changed       = (SFBool) getEventOut( "load_changed" );
      bboxCenter         = (SFVec3f) getField( "bboxCenter" );
      bboxCenter_changed = (SFVec3f) getEventOut( "bboxCenter_changed" );
      bboxSize           = (SFVec3f) getField( "bboxSize" );
      bboxSize_changed   = (SFVec3f) getEventOut( "bboxSize_changed" );
      value_changed      = (SFInt32) getEventOut( "value_changed" );
      empty_node         = (MFNode) getField( "empty_node" );
      empty_string       = (MFString) getField( "empty_string" );
      debug              = ((SFBool) getField( "debug" )).getValue();

      // Initialise any eventOuts to default values
      children.setValue( (ConstMFNode) ((Node) group.getValue()).getEventOut(
		         "children" ) );
      if (geo_url.getSize() != 0)
        geourl_changed.setValue( geourl );
      load_changed.setValue( load );
      bboxCenter_changed.setValue( bboxCenter );
      bboxSize_changed.setValue( bboxSize );
      if ( load == true ) initiate_load();
    }
  }

  // Load the inline scene, if not already loaded

  public void loadUrl() {
    if ( load == false ) initiate_load();
  }

  // Remove the current inline nodes from the scene, if loaded

  public void unloadUrl() {
    if ( load == true ) {
      MFNode rc = (MFNode) ((Node) group.getValue()).getEventIn(
		   "removeChildren" );
      rc.setValue( (ConstMFNode) ((Node) group.getValue()).getEventOut(
		   "children") );
      children.setValue( empty_node );
      load = false;
      load_changed.setValue( false );
      ///if ( debug ) System.out.println( "Unloading "+geourl[0] );
    }
  }

  // The shutdown method is called when this object is destroyed

  public void shutdown() {
    unloadUrl();
  }

  // Handle all of the eventIn's that we support....

  public void processEvent( Event e ) {
    String event_name = e.getName();
    ///System.out.println("QuadLODInline.processEvent: " + event_name);

    // The set_load eventIn is used to load or unload the nodes
    // for the Inline from the scene graph. Checks are made so
    // that we don't try to load a file if it is already loaded
    // and we don't try to unload a file if there is no file loaded
    
    if ( event_name.equals( "set_load" ) ) {
      boolean new_load = ((ConstSFBool) e.getValue()).getValue();
      ///System.out.println("QuadLODInline.processEvent: set_load " + (new_load ? "true" : "false"));
      
      if ( load != new_load ) {
	if ( new_load == true ) {
	  loadUrl();
	} else {
	  unloadUrl();
	}
      }
      
      // The set_url eventIn is used to change the url of the 
      // Inline node and to cause this url to be loaded if the
      // current state of the node is load == true.
      
    } else if ( event_name.equals( "set_url" ) ) {
      ConstMFString mfs = (ConstMFString) e.getValue();
      String[] new_url = new String[mfs.getSize()];
      mfs.getValue( new_url );
      
      if ( load == true ) {
	unloadUrl();
	geourl = new_url;
	loadUrl();
      } else {
	geourl = new_url;
      }
      geourl_changed.setValue( new_url );
      
      // The set_bboxCenter eventIn is used to change the bounding
      // box center point that is used for the VisiblitySensor
      
    } else if ( event_name.equals( "set_bboxCenter" ) ) {
      float[] new_center = new float[3];
      ((ConstSFVec3f) e.getValue()).getValue( new_center );
      
      SFVec3f nc = (SFVec3f) ((Node) VizSensor.getValue()).getEventIn(
                   "center" );
      nc.setValue( new_center );
      bboxCenter.setValue( new_center );
      bboxCenter_changed.setValue( new_center );
      
      // The set_bboxSize eventIn is used to change the bounding
      // box dimensions that are used for the VisiblitySensor
      
    } else if ( event_name.equals( "set_bboxSize" ) ) {
      float[] new_size = new float[3];
      ((ConstSFVec3f) e.getValue()).getValue( new_size );
      
      SFVec3f ns = (SFVec3f) ((Node) VizSensor.getValue()).getEventIn(
                    "size" );
      ns.setValue( new_size );
      bboxSize.setValue( new_size );
      bboxSize_changed.setValue( new_size );
      
      // The set_value eventIn is used to change the whichChoice
      // field of the Switch node to switch in or out any loaded
      // nodes when they are not visible. We switch the loaded
      // nodes out only if a valid bounding box has been specified.
      
    } else if ( event_name.equals( "set_value" ) ) {
      boolean new_value = ((ConstSFBool) e.getValue()).getValue();
      int     new_setting = 0;
      
      if ( bboxSize.getX() != -1 && new_value == false )
	new_setting = -1;
      ///System.out.println("box: " + bboxCenter.getX() + " " + bboxCenter.getY() + " " + bboxCenter.getZ());
      ///System.out.println("box: " + bboxSize.getX() + " " + bboxSize.getY() + " " + bboxSize.getZ());
      
      value_changed.setValue( new_setting );
      
      ///if ( debug ) System.out.println( "Set Switch to "+new_setting+" for "+geourl[0] );
      
      // The nodesLoaded event is only used within this object.
      // It used called by createVrmlFromURL when it has completed
      // the loading of the Inline url file
      
    } else if ( event_name.equals( "nodesLoaded" ) ) {
      ConstMFNode new_nodes = (ConstMFNode) e.getValue();

      MFNode ac = (MFNode) ((Node) group.getValue()).getEventIn( 
		  "addChildren" );
      ac.setValue( new_nodes );

      Node[] nodes = new Node[new_nodes.getSize()];
      new_nodes.getValue( nodes );
      children.setValue( nodes );

      // Store this tile into the cache
      cacheTiles.insert(geourl[0], new_nodes);

      //if ( nodes[0].getType().equals( "QuadLOD" ) ) {
	//quadlod = nodes[0];

	//browser.addRoute( nodes[0], "children", this, "quadlod_loaded" );
	// System.out.println( "Setting QuadLOD: " + quadlod.toString() );

	//        int         numb_children = ((ConstMField) nodes[0].getEventOut( "children" )).getSize();
	//System.out.println( "Numb Children = " + numb_children );
	//	final int   numb_children = 10;
	//Node[]      children_nodes = new Node[numb_children];
	//ConstMFNode lod_children = new ConstMFNode( numb_children, children_nodes );
	//ConstMFNode lod_choice;
	//ConstSFBool test_bool = new ConstSFBool(false);
	//Node        lod_switch, lod_inline;
	
	//if ( quadlod.getEventOut( "children" ) == null )
	//System.out.println( "QuadLOD NULL" );
	//else
	//System.out.println( "QuadLOD Not NULL" );

	// lod_children = (ConstMFNode) nodes[0].getEventOut( "children" );
	//try {
	//  test_bool = (ConstSFBool) nodes[0].getEventOut( "enabled_changed" );
	//} catch ( InvalidEventOutException ex ) {
	//  System.out.println( "EXCEPTION" );
        //}
	//System.out.println( "test_bool = " + test_bool );
	//	lod_switch = (Node) lod_children.get1Value(0);
	//	System.out.println( "3" );
	//lod_choice = (ConstMFNode) lod_switch.getEventOut( "choice" );
	//System.out.println( "4" );
	//lod_inline = (Node) lod_choice.get1Value(0);
	//System.out.println( "5" );

	//System.out.println( "Nested URL = " +
	//((ConstMFString) lod_inline.getEventOut( "url_changed" )).get1Value(0) );

      //}

      load = true;
      load_changed.setValue( true );

    } else if ( event_name.equals( "quadlod_loaded" ) ) {
      ///System.out.println( "GOT quadlod_loaded!" );
      //if ( quadlod == null ) return;
      //System.out.println( "Got QuadLOD: " + quadlod.toString() );
      
      //if ( quadlod.getEventOut( "children" ) == null )
      //System.out.println( "QuadLOD NULL" );
      //else
      //System.out.println( "QuadLOD Not NULL ********" );

      //quadlod = null;
    } 
 
  }

}

// EOF: QuadLODInline.java
