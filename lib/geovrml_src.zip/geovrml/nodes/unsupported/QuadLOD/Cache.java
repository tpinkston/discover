//
// Cache.java by Kiril Vidimce.
//
// (c) SRI International, 1998. Menlo Park, CA 94025.
//
// Implements a simple LRU cache system for use with the QuadLOD node.
//
// $Id: Cache.java,v 1.1.1.1 2000/06/15 16:49:27 reddy Exp $
//

import java.util.Vector;
import vrml.field.*;

class Cache 
{
  private Vector urls = null;
  private Vector tiles = null;
  private int size = 0;
  private int count = 0;
 
  Cache(int cacheSize)
  {
    tiles = new Vector(size, 10);
    urls = new Vector(size, 10);
    size = cacheSize;
  }

  synchronized void insert(String url, ConstMFNode tile)
  {
    if (count == size)
    {
      remove();
    }
    urls.addElement(url);
    tiles.addElement(tile);
    ++count;
  }

  synchronized void remove()
  {
    Object o;

    if (count == 0)
    {
      // System.out.println("Cache is empty");
      return;
    }
    o = urls.firstElement();
    urls.removeElement(o);

    o = tiles.firstElement();
    tiles.removeElement(o);

    --count;
  }

  synchronized void remove(String url, ConstMFNode tile)
  {
    if (count == 0)
    {
      // System.out.println("Cache is empty");
      return;
    }
    url  = (String) urls.firstElement();
    tile = (ConstMFNode) tiles.firstElement();

    urls.removeElement(url);
    tiles.removeElement(tile);

    --count;
  }

  synchronized ConstMFNode get(String url)
  {
    for (int i = 0; i < count; i++)
    {
      if (url.equals((String) urls.elementAt(i)))
      {
        return (ConstMFNode) tiles.elementAt(i);
      }
    }
    return null;
  }

  int getSize()  
  {
    return size;
  }

  int getCount()  
  {
    return count;
  }
}
