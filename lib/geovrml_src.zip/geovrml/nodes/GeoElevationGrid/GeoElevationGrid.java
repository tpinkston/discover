//
// Filename: GeoElevationGrid.java
//
// Author:
//   Martin Reddy, SRI International.
//   Heiko Grussbach, Centre Recherche Henri Tudor
//   Yong-Tze Chi, SRI International
//
// Purpose:
//   This class implements a new ElevationGrid node for VRML. It enables the
//   specification of coordinates in coordinate systems other than the
//   basic VRML Cartesian XYZ system. We support a number of geographic
//   coordinate systems such as lat/long and UTM.
//
//   This code requires access to the GeoTransform Java package, included
//   as part of the GeoVRML source code distribution.
//
// License:
//   The contents of this file are subject to GeoVRML Public License
//   Version 1.0 (the "License"); you may not use this file except in
//   compliance with the License. You may obtain a copy of the License at
//   http://www.geovrml.org/1.0/license/.
//
//   Software distributed under the License is distributed on an "AS
//   IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
//   implied. See the License for the specific language governing
//   rights and limitations under the License.
//
//   Portions are Copyright (c) SRI International, 2000.
//
// Revision:
//   Martin Reddy: initial version
//   Heiko Grussbach (28 Feb 2000): optimized conversion to GCC
//   Yong-Tze Chi (20 Jul 2000): get round get1Value() error in Cosmo
//
//   $Id: GeoElevationGrid.java,v 1.2 2002/03/08 00:30:25 reddy Exp $
//

import java.lang.*;
import vrml.*;
import vrml.field.*;
import vrml.node.*;
import geotransform.coords.Gcc_Coord_3d;
import org.web3d.geovrml.GeoVRML;

public class GeoElevationGrid extends Script {

  GeoVRML geovrml = null;
  double  yScale;
  double  xInc, zInc;
  int     xDimension, zDimension;
  boolean debug = false;
  Node    ifs, coord;
  MFFloat height = null;
  String  geo_system;
  String  geoGridOrigin;

  // regenerate() will build the vertex lists based upon the current
  // GeoElevationGrid state, e.g. yScale, height array, etc.

  private void regenerate() {

    // get the texCoord coordinate list. If vrml_texpoint is non-null
    // after this, then we need to generate texture coordinates

    float h[];

    float vrml_texpoint[] = null;
    Node texCoordNode = null;
    MFVec2f tex_point = null;

    SFNode texCoord = (SFNode) ifs.getExposedField( "texCoord" );
    if ( texCoord != null ) {
      texCoordNode = (Node) texCoord.getValue();
      if ( texCoordNode != null ) {
	tex_point = (MFVec2f) texCoordNode.getExposedField( "point" );
	if ( tex_point.getSize() == 0 )
	  vrml_texpoint = new float[ xDimension * zDimension * 2 ];
      }
    }

    // let's allocate an array to hold all of the (x,y,z) coords

    float vrml_point[] = new float[ xDimension * zDimension * 3 ];

    // loop through all height field values

    int h_index = 0, p_index = 0, t_index = 0;

    //Insertion starts Heiko Grussbach
    double[] geoGridOriginArray=new double[3];
    double[] new_coord=new double[3];

    geoGridOriginArray=geovrml.getValues(geoGridOrigin,3);
    float xDiv=1.0f/( xDimension - 1.0f );
    float zDiv=1.0f/( zDimension - 1.0f );
    //Insertion ends Heiko Grussbach

    h = new float[zDimension * xDimension];
    height.getValue(h);

    for ( int z = 0; z < zDimension; z++ ) {
      for ( int x = 0; x < xDimension; x++ ) {

	// get this elevation value (implement vertical exaggeration here)

	// double elev = (double) height.get1Value( h_index++ ) * yScale;
        double elev = (double) h[h_index++] * yScale;

	// work out the string describing this new geographic location

	//Change starts Heiko Grussbach
	geovrml.addCoord( new_coord, geoGridOriginArray, xInc*x, zInc*z,
			  elev, geo_system );
	//Change ends Heiko Grussbach

	if ( new_coord == null ) return;

	// convert this into GCC

	Gcc_Coord_3d gcc = geovrml.getCoord( new_coord, geo_system );

	// and then add it to our list of floats

	vrml_point[p_index++] = (float) ( gcc.x ); // / 1000000.0 );
	vrml_point[p_index++] = (float) ( gcc.y ); // / 1000000.0 );
	vrml_point[p_index++] = (float) ( gcc.z ); // / 1000000.0 );

	// and update our texture coordinate list too

	if ( vrml_texpoint != null ) {
	  //Change starts, Heiko Grussbach
	  vrml_texpoint[t_index++] = (float) x *xDiv;
	  vrml_texpoint[t_index++] = (float) z *zDiv;
	  //Change ends, Heiko Grussbach
	}

	if ( debug )
	  System.out.println( h_index + ": " +
			      vrml_point[p_index-3] + ", " +
			      vrml_point[p_index-2] + ", " +
			      vrml_point[p_index-1] + " : " + new_coord );
      }
    }

    h = null;

    // Now let's make the coords field of our Coordinate node 
    // equal to the list of coordinates that we have just built

    MFVec3f coord_point = (MFVec3f) coord.getExposedField( "point" );
    coord_point.setValue( p_index, vrml_point );

    // set the texCoord field if we are generating texture coords

    if ( vrml_texpoint != null && tex_point != null ) {
      tex_point.setValue( t_index, vrml_texpoint );
    }

    // let's make the coordIndex entries. These are a bit easier!

    int values[] = new int[ ( xDimension -1 ) * ( zDimension - 1 ) * 5 ];

    int index = 0;

    for ( int z = 0; z < zDimension - 1; z++ ) {
      for ( int x = 0; x < xDimension - 1; x++ ) {
	values[index]   = x + z * xDimension;
	values[index+1] = values[index] + 1;
	values[index+2] = values[index+1] + xDimension;
	values[index+3] = values[index+2] - 1;
	values[index+4] = -1;

	if ( debug )
	  System.out.println( "Poly: " + values[index] + " " +values[index+1] +
			      " " + values[index+2] + " " + values[index+3] +
			      "  (" + x + "," + z + ": " + index + ")" );
	index += 5;
      }
    }

    MFInt32 coord_index = (MFInt32) ifs.getEventIn( "set_coordIndex" );
    coord_index.setValue( index, values );

    // we're done!

    if ( debug )
      System.out.print( "GeoElevationGrid: done." );

  }

  // processEvent deals with all of the eventIns that we support.
  // Currently this includes set_yScale and set_height

  public void processEvent( Event e ) {

    if ( debug ) System.out.println( "Event received: " + e.getName() );

    // set_yScale lets you change the vertical exaggeration on the fly

    if ( e.getName().equals( "set_yScale" ) ) {
      ConstSFFloat value = (ConstSFFloat) e.getValue();
      yScale = value.getValue();
      regenerate();
    }    

    // set_height lets you change the height values on the fly

    if ( e.getName().equals( "set_height" ) ) {
      ConstMFFloat cmffloat = (ConstMFFloat) e.getValue();
      float values[] = new float[cmffloat.getSize()];
      cmffloat.getValue( values );
      height = new MFFloat( values );
      regenerate();
    }    

  }

  // The initialize method is called when the Node is first loaded.
  // Here we grab copies of any necessary fields/eventIn/eventOuts

  public void initialize() {

    // Take copies of all the fields for this node

    SFNode   geoOrigin     = (SFNode) getField( "geoOrigin" );
    MFString geoSystem     = (MFString) getField( "geoSystem" );

    SFString xSpacing      = (SFString) getField( "xSpacing" );
    SFString zSpacing      = (SFString) getField( "zSpacing" );

    geoGridOrigin = ((SFString) getField("geoGridOrigin")).getValue();
    height        = (MFFloat) getField( "height" );
    xDimension    = ((SFInt32) getField( "xDimension" )).getValue();
    zDimension    = ((SFInt32) getField( "zDimension" )).getValue();
    yScale        = (double)((SFFloat) getField( "yScale" )).getValue();

    coord         = (Node) ((SFNode) getField( "coord" )).getValue();
    ifs           = (Node) ((SFNode) getField( "ifs" )).getValue();

    debug         = ((SFBool) getField( "debug" )).getValue();

    // convert the spacing strings into double values

    xInc = (Double.valueOf(xSpacing.getValue())).doubleValue();
    zInc = (Double.valueOf(zSpacing.getValue())).doubleValue();

    // ready to start...

    if ( debug )
      System.out.println( "GeoElevationGrid: " + xDimension + " x " +
			  zDimension + "(" + xInc + ":" + zInc + ")" );

    // do some sanity checks

    if ( xDimension < 2 || zDimension < 2 ) {
      System.out.println( "xDimension and zDimension must be >= 2" );
      return;
    }

    // Okay, let's initialise the GeoVRML utility class
    // These classes should be installed on the user's system and in
    // their CLASSPATH. If they are not, then we can't do anything!

    try {
      geovrml = new GeoVRML();
    } catch ( NoClassDefFoundError e ) {
      System.out.println( "GeoTransform classes not installed in CLASSPATH!" );
      return;
    }

    geovrml.setOrigin( geoOrigin );
    geo_system = geovrml.VRMLToString( geoSystem );

    // build the IndexedFaceSet from the GeoElevationGrid data

    regenerate();
  }

}

// EOF: GeoElevationGrid.java
