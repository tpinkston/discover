//
// Filename: GeoLOD.java
//
// Authors:
//   Martin Reddy, SRI International
//   Heiko Grussbach, Centre Recherche Henri Tudor
//
// Purpose:
//   This class implements a new LOD node for VRML called GeoLOD. This
//   aims to provide a specialised solution for supporting the large,
//   multi-resolution terrain grids. The node will switch the
//   representation of a feature based upon its distance from the
//   viewpoint. Only two levels of detail can be specified, however
//   arbitarily deep hierarchies can be produced by nesting several
//   GeoLOD nodes. The node works by displaying a single piece of
//   geometry by default. Then when the viewpoint nears this geometry
//   it is replaced by four alternative geometries. This is meant to
//   represent a single low resolution terrain tile that is then
//   subdivided into four higher resolution quadrants, i.e. a quadtree
//   structure.
//
//   This code requires access to the GeoTransform Java package, included
//   as part of the GeoVRML source code distribution.
//
// License:
//   The contents of this file are subject to GeoVRML Public License
//   Version 1.0 (the "License"); you may not use this file except in
//   compliance with the License. You may obtain a copy of the License at
//   http://www.geovrml.org/1.0/license/.
//
//   Software distributed under the License is distributed on an "AS
//   IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
//   implied. See the License for the specific language governing
//   rights and limitations under the License.
//
//   Portions are Copyright (c) SRI International, 2000.
//
// Revision:
//   Martin Reddy (7 Nov 1999): first version
//   Heiko Grussbach (22 Mar 2000): fixes for set_children() under Cortona
//   Martin Reddy (29 Mar 2000): switch when all *defined* urls are loaded
//
//   $Id: GeoLOD.java,v 1.3 2002/03/12 19:49:23 reddy Exp $
//

import java.lang.*;
import vrml.*;
import vrml.field.*;
import vrml.node.*;
import geotransform.coords.Gcc_Coord_3d;
import org.web3d.geovrml.GeoVRML;
import org.web3d.geovrml.Quaternion;

public class GeoLOD extends Script {
  
  // Java versions of the Script's fields and eventOuts
   
  private MFNode     rootNode;           // field
  private float      range;              // field
  private MFNode     children;           // eventOut

  private SFNode     switch_node;        // field
  private Node       prox_node;          // field
  private Node       lores_node;         // field
  private Node       hires_node;         // field

  private boolean    debug;              // field

  // Internal state variables

  private MFString[] url = new MFString[5];
  private boolean[]  loaded = new boolean[5];
  private boolean[]  isloading = new boolean[5];
  private boolean[]  defined = new boolean[5];
  private int        selected = 0;

  private Browser    browser = null;

  // set the new children of the switch node.
  // Code segment by Heiko Grussbach, heiko.grussbach@crpht.lu

  private void set_children() {
    if ( children.getSize() == 0 )
      children.addValue( switch_node );
    else
      children.set1Value( 0, switch_node );
  }

  // The initiate_load() method is used to load the scene for the
  // one of the 5 URLs. It uses the Browser method createVrmlFromURL to
  // perform this. Once the scene has been loaded, a nodesLoaded<n>
  // eventIn is sent to the processEvent() method below.

  public synchronized void initiate_load( int which_url ) {

    if ( which_url == 0 && rootNode.getSize() != 0 ) {

      // if we are loading the root scene and it is supplied
      // as an MFNode rather than a URL, then just plug them in

      MFNode ac = (MFNode) lores_node.getEventIn( "addChildren" );
      ac.setValue( rootNode );

      loaded[0] = true;

      setSelected( 0 );
      unloadChildren();
      // children.set1Value( 0, switch_node );
      set_children();

      if ( debug ) System.out.println( "Setting rootNode for url[0]" );

    } else if ( which_url == 0 && loaded[0] ) {

      // we never unload the root nodes (until this object is
      // destroyed), so check to see if these are already in memory
      // and just switch to them if this is the case

      setSelected( 0 );
      unloadChildren();
      // children.set1Value( 0, switch_node );
      set_children();

      if ( debug ) System.out.println( "Switch to cached root nodes" );
      
    } else {

      // otherwise, we need to load the specified url.
      // first, check that we have a valid browser object

      if ( browser == null ) {
	System.out.println( "Browser object not found: cannot load url" );
	return;
      }

      // how many strings are in this URL's MFString?

      int size = url[which_url].getSize();
      if ( size == 0 ) {
	if ( debug ) System.out.println( "url " + which_url + " empty" );
	return;
      }

      // load the specified URL

      String scene_url[] = new String[ url[which_url].getSize() ];
      url[which_url].getValue( scene_url );

      try {
	browser.createVrmlFromURL( scene_url, this, "nodesLoaded"+which_url );
      } catch ( InvalidVRMLSyntaxException e ) {
	System.out.println( "Couldn't Inline file: invalid VRML syntax" );
	return;
      }

      isloading[which_url] = true;

      if ( debug ) System.out.println( "Loading " + scene_url[0] );

    }

  }

  // The initialize method is called when the Node is first loaded.
  // Here we grab copies of any necessary fields/eventIn/eventOuts
  // and fire off initial values for the eventOuts.

  public void initialize() {

    // declare the local VRML objects that we only need at init time

    SFNode     geoOrigin;
    MFString   geoSystem;
    SFString   center;
    GeoVRML    geovrml;

    // Take copies of all the fields for this node

    rootNode     = (MFNode) getField( "rootNode" );
    url[0]       = (MFString) getField( "rootUrl" );
    url[1]       = (MFString) getField( "child1Url" );
    url[2]       = (MFString) getField( "child2Url" );
    url[3]       = (MFString) getField( "child3Url" );
    url[4]       = (MFString) getField( "child4Url" );

    range        = ((SFFloat) getField( "range" )).getValue();

    geoOrigin    = (SFNode) getField( "geoOrigin" );
    geoSystem    = (MFString) getField( "geoSystem" );
    center       = (SFString) getField( "center" );

    switch_node  = (SFNode) getField( "switch_node" );
    prox_node    = (Node) ((SFNode) getField( "prox_node" )).getValue();
    lores_node   = (Node) ((SFNode) getField( "lores_node" )).getValue();
    hires_node   = (Node) ((SFNode) getField( "hires_node" )).getValue();

    children     = (MFNode) getEventOut( "children" );
    debug        = ((SFBool) getField( "debug" )).getValue();

    // initialise the state for the root and each child 
    // If a url string is not defined, then we act as if it
    // has already been loaded into memory.

    for ( int i = 0; i < 5; i++ ) {
      defined[i]   = ( url[i] != null && url[i].getSize() > 0 );
      loaded[i]    = ! defined[i];
      isloading[i] = false;
    }

    if ( debug ) System.out.println( "range = " + range );

    // we double the range because we use it to set the size of a 
    // *volume* around the center point, rather than a distance.

    range *= 2.0f;

    // set up the center field of the ProximitySensor
    // this is specified in some geographic coordinate system

    if ( center.getValue().length() > 0 ) {

      // Okay, let's initialise the GeoVRML utility class.
      // These should be installed in the user's CLASSPATH

      try {
	geovrml = new GeoVRML();
      } catch ( NoClassDefFoundError e ) {
	System.out.println( "GeoVRML classes not installed in CLASSPATH!" );
	return;
      }

      geovrml.setOrigin( geoOrigin );

      // convert the geographic coordinate into VRML coordinates

      Gcc_Coord_3d gcc = geovrml.getCoord( center, geoSystem );

      if ( debug ) System.out.println( "center = " + gcc.x + ", " + gcc.y
				       + ", " + gcc.z );

      // update the center SFVec3f field of the ProximitySensor

      SFVec3f prox_center = (SFVec3f) prox_node.getExposedField( "center" );
      prox_center.setValue( (float) gcc.x, (float) gcc.y, (float) gcc.z );

    }

    // set up the size of the ProximitySensor and enable it

    SFVec3f prox_size = (SFVec3f) prox_node.getExposedField( "size" );
    prox_size.setValue( range, range, range );

    SFBool prox_enabled = (SFBool) prox_node.getExposedField( "enabled" );
    prox_enabled.setValue( true );
      
    // Grab the VRML Browser object

    browser = getBrowser();

    // Load the rootUrl, or the rootNode if specified

    initiate_load( 0 );

  }

  // set the whichChoice field of the Switch node, new_value = 0 or 1

  public void setSelected( int new_value ) {
    if ( new_value == selected ) return;
    
    Node    snode = (Node) switch_node.getValue();
    SFInt32 which = (SFInt32) snode.getExposedField( "whichChoice" );
    which.setValue( new_value );
    selected = new_value;

    if ( debug ) System.out.println( "Switch node whichChoide = " + new_value);
  }

  // deals with the nodes that were loaded for a specific URL

  public synchronized void nodesLoaded( ConstMFNode nodes, int which_url ) {

    if ( debug ) System.out.println( "Event received: nodesLoaded"+which_url );

    // check for error condition, e.g. file not found

    if ( nodes == null || nodes.getSize() == 0 ) {
      if ( debug ) System.out.println( "Could not load URL " + which_url ); 
      loaded[which_url]    = false;
      isloading[which_url] = false;
      return;
    }

    // update the state for this URL

    loaded[which_url]    = true;
    isloading[which_url] = false;

    // did we load the root (which_url==0) or a child URL?

    if ( which_url == 0 ) {

      // we have loaded the root url - set it up appropriately

      MFNode ac = (MFNode) lores_node.getEventIn( "addChildren" );
      ac.setValue( nodes );

      // set the new children to the switch node.
      // Code segment by Heiko Grussbach, heiko.grussbach@crpht.lu

      setSelected( 0 );

      // children.set1Value( 0, switch_node );
      set_children();

      unloadChildren();

    } else {

      // we have loaded one of the 4 children urls - add to scene graph

      MFNode ac = (MFNode) hires_node.getEventIn( "addChildren" );
      ac.setValue( nodes );

      // have all defined children been loaded? If so, switch them all in

      if ( loaded[1] && loaded[2] && loaded[3] && loaded[4] ) {

	// set the new children to the switch node.
	// Code segment by Heiko Grussbach, heiko.grussbach@crpht.lu

	setSelected( 1 );
	// children.set1Value( 0, switch_node );
	set_children();
      }

    }

  }

  // unload the nodes for a specified Group node, if any exist

  public synchronized void unloadNodes( Node group_node ) {
    MFNode nc, rc;

    try {
      nc = (MFNode) group_node.getExposedField( "children" );
    } catch ( InvalidExposedFieldException e ) {
      if ( debug ) e.printStackTrace();
      return;
    }

    if ( nc.getSize() == 0 ) return;

    try {
      rc = (MFNode) group_node.getEventIn( "removeChildren" );
    } catch ( InvalidExposedFieldException e ) {
      if ( debug ) e.printStackTrace();
      return;
    }

    rc.setValue( nc );
  }

  // unload the nodes for the root 

  public void unloadRoot() {
    unloadNodes( lores_node );
    loaded[0] = false;
  }

  // unload the nodes for the children

  public void unloadChildren() {
    unloadNodes( hires_node );
    loaded[1] = ! defined[1];
    loaded[2] = ! defined[2];
    loaded[3] = ! defined[3];
    loaded[4] = ! defined[4];
  }

  // The shutdown method is called when this object is destroyed

  public synchronized void shutdown() {
    unloadRoot();
    unloadChildren();
  }

  // Handle all of the eventIn's that we support....

  public synchronized void processEvent( Event e ) {
    String event_name = e.getName();

    if ( event_name.equals( "isActive" ) ) {

      // The isActive eventIn is fed from the isActive eventOut of
      // the ProximitySensor. This tells us when to switch resolutions
    
      boolean active = ((ConstSFBool) e.getValue()).getValue();

      if ( active ) {
	
	/* if in the hires zone then load all the hires children */

	for ( int i = 1; i <= 4; i++ )
	  if ( loaded[i] == false && isloading[i] == false )
	    initiate_load( i );

      } else {

	/* if not in the hires zone then go back to the lores root */

	initiate_load( 0 );

      }

    } else if ( event_name.equals( "nodesLoaded0" ) ) {
      nodesLoaded( (ConstMFNode) e.getValue(), 0 );

    } else if ( event_name.equals( "nodesLoaded1" ) ) {
      nodesLoaded( (ConstMFNode) e.getValue(), 1 );

    } else if ( event_name.equals( "nodesLoaded2" ) ) {
      nodesLoaded( (ConstMFNode) e.getValue(), 2 );

    } else if ( event_name.equals( "nodesLoaded3" ) ) {
      nodesLoaded( (ConstMFNode) e.getValue(), 3 );

    } else if ( event_name.equals( "nodesLoaded4" ) ) {
      nodesLoaded( (ConstMFNode) e.getValue(), 4 );

    }

  }
}

// EOF: GeoLOD.java
