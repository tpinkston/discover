//
// Filename: GeoProximitySensor.java
//
// Authors:
//   Mike McCann, MBARI - 3 December 2001
//
// Purpose:
//   This class implements a new Sensor node for VRML. It allows you
//   to track the proximity to any GeoLocation.
//
//   This code requires access to the GeoTransform Java package, included
//   as part of the GeoVRML source code distribution.
//
// License:
//   The contents of this file are subject to GeoVRML Public License
//   Version 1.0 (the "License"); you may not use this file except in
//   compliance with the License. You may obtain a copy of the License at
//   http://www.geovrml.org/1.0/license/.
//
//   Software distributed under the License is distributed on an "AS
//   IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
//   implied. See the License for the specific language governing
//   rights and limitations under the License.
//
//   Portions are Copyright (c) MBARI, 2001.
//
// Revision:
//   $Id: GeoProximitySensor.java,v 1.3 2003/07/25 19:05:00 mccann Exp $
//
//

import java.lang.*;
import vrml.*;
import vrml.field.*;
import vrml.node.*;
import geotransform.coords.Gcc_Coord_3d;
import org.web3d.geovrml.GeoVRML;
import org.web3d.geovrml.Quaternion;

public class GeoProximitySensor extends Script {

  Gcc_Coord_3d gcc;

  MFString geoSystem;
  SFString geoCenter;
  SFNode geoOrigin;
  GeoVRML geovrml;
  Node transform;
  boolean debug;
  String geo_system = null;

  SFVec3f position_changed;
  SFRotation orientation_changed;
  SFString geoCoord_changed;

  SFString geoCenter_changed;
  SFVec3f size_changed;
  SFVec3f center_changed;

  SFBool isActive;
  SFTime enterTime;
  SFTime exitTime;


  public void processEvent( Event e ) {

	String name = e.getName();
	Object value = e.getValue();

	if ( debug ) System.out.println( "  Event received: " + name );

        // Simply route most events thru; on position_changed also send out geoCoord
        if ( name.equals( "PS_position_changed" ) ) {
	  position_changed.setValue((ConstSFVec3f)value);
          if (debug ) System.out.println( " geoCoord = " + geovrml.geoCoord((ConstSFVec3f)value, geo_system) );
          geoCoord_changed.setValue(geovrml.geoCoord((ConstSFVec3f)value, geo_system));
        }
        else if ( name.equals( "PS_orientation_changed" ) ) {
	  orientation_changed.setValue((ConstSFRotation)value);
        }
        else if ( name.equals( "set_geoCenter" ) ) {
          ConstSFString csfstring = (ConstSFString) e.getValue();
          SFString sfstring = new SFString();
          sfstring.setValue(csfstring);
          if ( debug )
            System.out.println( "  processEvent(): attempting to set geoCenter to " + sfstring );  
	  geoCenter.setValue(sfstring);
	  
	  if ( debug )
            System.out.println( "  processEvent(): attempting to set geoCenter_changed to " + sfstring);
          geoCenter_changed.setValue(sfstring);
          
          // Set LVCS center_changed 
          
          try {
            gcc = geovrml.getCoord( geoCenter, geoSystem );
            center_changed.setValue( (float)gcc.x, (float)gcc.y, (float)gcc.z);
          }
          catch (Exception ex ) {
      	    // Cosmo sometimes processes events before initialize() finishes and we hava a gcc!
      	    System.out.println("GeoProximitySensor{}:");
      	    System.out.println("  processEvent(): *** Failed to set center_changed for event set_geoCenter ***");
      	    System.out.println("                  gcc is probably null because initialize() did not finish yet");
      	    System.out.println("                  Specify the geoCenter field to avoid this message");
          }
          if ( debug )
            System.out.println( "  processEvent(): LVCS center_changed to = " + (float)gcc.x +
              " " + (float)gcc.y + " " + (float)gcc.z );
        }
        else if ( name.equals( "set_size" ) ) {
           // Set LVCS size_changed
          if ( debug )
            System.out.println( "  processEvent(): setting LVCS size to " + value );
          size_changed.setValue((ConstSFVec3f)value);
        }
        else if ( name.equals( "PS_isActive" ) ) {
          if ( debug )
            System.out.println( "  processEvent(): setting isActive to " + value );
	  isActive.setValue((ConstSFBool)value);
        }
        else if ( name.equals( "PS_enterTime" ) ) {
          if ( debug )
            System.out.println( "  processEvent(): setting enterTime to " + value );
	  enterTime.setValue((ConstSFTime)value);
        }
        else if ( name.equals( "PS_exitTime" ) ) {
          if ( debug )
            System.out.println( "  processEvent(): setting exitTime to " + value );
	  exitTime.setValue((ConstSFTime)value);
        }

  }

  // The initialize method is called when the Node is first loaded.
  // Here we grab copies of any necessary fields/eventIn/eventOuts
  // and do the coordinate transformation in order to find the
  // correct geolocation for the transform's childrens.

  public void initialize() {

    // Take copies of all the fields for this node.

    geoOrigin = (SFNode) getField( "geoOrigin" );
    geoSystem = (MFString) getField( "geoSystem" );

    // Get fields via dummy nodes mapped by the proto
    
    Node def_geoCenter = (Node) ((SFNode) getField( "def_geoCenter" )).getValue();
    geoCenter = (SFString) def_geoCenter.getExposedField( "description" );
    
    Node def_size = (Node) ((SFNode) getField( "def_size" )).getValue();
    SFVec3f size = (SFVec3f) def_size.getExposedField( "axisOfRotation" );
    
    
    debug = ((SFBool) getField( "debug" )).getValue();

    position_changed = (SFVec3f) getEventOut( "position_changed" );

    orientation_changed = (SFRotation) getEventOut( "orientation_changed" );
    geoCoord_changed = (SFString) getEventOut( "geoCoord_changed" );

    geoCenter_changed = (SFString) getEventOut( "geoCenter_changed" );
    size_changed = (SFVec3f) getEventOut( "size_changed" );
    center_changed = (SFVec3f) getEventOut( "center_changed" );

    isActive = (SFBool) getEventOut( "isActive" );
    enterTime = (SFTime) getEventOut( "enterTime" );
    exitTime = (SFTime) getEventOut( "exitTime" );

    if ( debug ) System.out.println( "GeoProximitySensor:" );

    // Okay, let's initialise the GeoVRML utility class
    // These classes should be installed on the user's system and in
    // their CLASSPATH. If they are not, then we can't do anything!

    try {
      geovrml = new GeoVRML();
    } catch ( NoClassDefFoundError e ) {
      System.out.println( "GeoTransform classes not installed in CLASSPATH!" );
      return;
    }

    geovrml.setOrigin( geoOrigin );
    geo_system = geovrml.VRMLToString( geoSystem );

    if ( debug ) {
      System.out.println( "  initialize(): geoCenter = " + geoCenter );
    }
    
    // Set center of rotation to the geoCenter specified, if not specified then use the geoOrigin's coords
    
    if ( debug ) System.out.println( "  initialize(): geoCenter = " + geoCenter + "\n");
    Node GeoOrigin = (Node) ((SFNode) getField( "geoOrigin" )).getValue();
    SFString geoOriginCoords = (SFString) GeoOrigin.getExposedField( "geoCoords" );

    if ( geoCenter.getValue().length() > 0 ) {
      if ( debug ) System.out.println( "  initialize(): Setting gcc with geoCenter = " + geoCenter );  
    }
    else {
    	if ( debug ) System.out.println( "  initialize(): geoCenter not specified, using geoOrigin coords = " + geoOriginCoords );
        geoCenter.setValue(geoOriginCoords);
        if ( debug ) System.out.println( "  initialize(): Setting gcc with geoCenter = " + geoCenter );
    }
    // Set LVCS center_changed
    gcc = geovrml.getCoord( geoCenter, geoSystem );
    if ( debug )
      System.out.println( "  initialize(): setting LVCS center_changed to = " + (float)gcc.x +
              " " + (float)gcc.y + " " + (float)gcc.z );
    center_changed.setValue( (float)gcc.x, (float)gcc.y, (float)gcc.z);
  }

}

// EOF: GeoProximitySensor.java
