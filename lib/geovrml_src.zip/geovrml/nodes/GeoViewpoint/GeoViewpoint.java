//
// Filename: GeoViewpoint.java
//
// Author:
//   Martin Reddy, SRI International - 24 September 1999.
//
// Purpose:
//   This class implements a new Viewpooint node for VRML. It allows you
//   to specify the position and orientation of the viewpoint relative to
//   a geographic coordinate system such as lat/long or UTM.
//
//   This code requires access to the GeoTransform Java package, included
//   as part of the GeoVRML source code distribution.
//
// License:
//   The contents of this file are subject to GeoVRML Public License
//   Version 1.0 (the "License"); you may not use this file except in
//   compliance with the License. You may obtain a copy of the License at
//   http://www.geovrml.org/1.0/license/.
//
//   Software distributed under the License is distributed on an "AS
//   IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
//   implied. See the License for the specific language governing
//   rights and limitations under the License.
//
//   Portions are Copyright (c) SRI International, 2000.
//
// Revision:
//   $Id: GeoViewpoint.java,v 1.3 2002/03/12 19:49:23 reddy Exp $
//

import java.lang.*;
import vrml.*;
import vrml.field.*;
import vrml.node.*;
import geotransform.coords.Gcc_Coord_3d;
import org.web3d.geovrml.GeoVRML;
import org.web3d.geovrml.Quaternion;

public class GeoViewpoint extends Script {
  
  Node         viewpoint = null;
  Node         navinfo = null;
  // Node         proxsensor = null;
  boolean      debug = false;
  Gcc_Coord_3d gcc = null;
  GeoVRML      geovrml = null;
  MFString     geoSystem = null;
  SFBool       isBound = null;
  SFTime       bindTime = null;
  SFRotation   last_rot = null;
  float        speed_scale = 1.0f;

  private static boolean firstInstance = true;

  //
  // process_position takes an SFString describing a single
  // geographic coordinates (based upon the specified geoSystem)
  // and sets the position field of the Viewpoint node accordingly
  //

  private void process_position( SFString position ) {
    gcc = geovrml.getCoord( position, geoSystem );

    if ( debug ) System.out.println( " new viewpoint pos: " + gcc.x + ", "
				     + gcc.y + ", " + gcc.z );

    SFVec3f view_pos = (SFVec3f) viewpoint.getExposedField( "position" );
    view_pos.setValue( (float) gcc.x, (float) gcc.y, (float) gcc.z );
  }

  //
  // process_orientation takes an SFRotation describing a rotation
  // that is to be performed relative to the local oriention frame
  // defined by the currently location.
  //

  private void process_orientation( SFRotation orientation ) {
    float  local_orient[] = new float[4];
    float  rel_orient[] = new float[4];

    last_rot = null;
    last_rot = orientation;

    geovrml.getLocalOrientation( gcc, local_orient );
    orientation.getValue( rel_orient );

    /* convert orientation angles from radians to degrees */

    local_orient[3] *= ( 180.0 / Math.PI );
    rel_orient[3]   *= ( 180.0 / Math.PI );

    /* make quaternions out of the two VRML axis/angle rotations */

    Quaternion local_quat = new Quaternion();
    Quaternion rel_quat   = new Quaternion();
    Quaternion comb_quat  = new Quaternion();

    local_quat.rotation( (double) local_orient[0], (double) local_orient[1],
			 (double) local_orient[2], (double) local_orient[3] );

    rel_quat.rotation( (double) rel_orient[0], (double) rel_orient[1],
		       (double) rel_orient[2], (double) rel_orient[3] );

    /* now combine these together and return the axis/angle */

    comb_quat.add( rel_quat, local_quat );

    double axis[] = new double[3];
    double angle  = comb_quat.axis_angle( axis );

    // return the answer as a single-precision VRML angle/axis vector

    float orient[] = new float[4];
    orient[0] = (float) axis[0];
    orient[1] = (float) axis[1];
    orient[2] = (float) axis[2];
    orient[3] = (float) angle;

    /* and finally set the viewpoint orientation field appropriately */

    if ( debug ) System.out.println( " new viewpoint orient: " + orient[0]
				     + ", " + orient[1] + ", " + orient[2]
                                     + ", " + orient[3] );

    SFRotation view_orient;
    view_orient = (SFRotation) viewpoint.getExposedField("orientation");
    view_orient.setValue( orient[0], orient[1], orient[2], orient[3] );
  }

  //
  // new_camera takes a VRML coordinate, works out the height above
  // the WGS84 ellipsoid of this point, then scales the navigation
  // speed and near/far clipping planes based upon this height.
  //
  
  public void new_camera( double nx, double ny, double nz ) {

    // calculate the user's height above the WGS84 ellipsoid

    double elev = geovrml.getElevation( nx, ny, nz );

    // Set the NavigationInfo node's speed value

    float  speed = ((float) elev) / 10.0f * speed_scale;

    SFFloat nav_speed;
    nav_speed = (SFFloat) navinfo.getExposedField( "speed" );
    nav_speed.setValue( speed );

    // Scale the NavigationInfo's avatarSize vector by the speed
    // this controls the near/far clipping plane locations.

    float values[] = new float[3];

    values[0] = 0.25f * speed;
    values[1] = 1.6f * speed;
    values[2] = 0.75f * speed;

    MFFloat avatarSize;
    avatarSize = (MFFloat) navinfo.getExposedField( "avatarSize" );
    avatarSize.setValue( 3, values );

    if ( debug ) System.out.println( "Camera moved: elev = " + elev +
				     " m, speed = " + speed + " m/s" );
  }

  //
  // processEvent deals with all of the eventIns that we support.
  // Currently this includes set_bind, set_position, and set_orientation
  //

  public void processEvent( Event e ) {

    if ( debug ) System.out.println( "Event received: " + e.getName() );

    // pass the set_bind eventIn to our underlying Viewpoint node
    // and output the updated values of the isBound/bindTime eventOuts

    if ( e.getName().equals( "set_bind" ) ) {
      SFBool      set_bind;
      ConstSFBool value = (ConstSFBool) e.getValue();

      // send the event to the Viewpoint set_bind eventIn

      set_bind = (SFBool) viewpoint.getEventIn( "set_bind" );
      set_bind.setValue( value );

      // send the event to the NavigationInfo set_bind eventIn

      set_bind = (SFBool) navinfo.getEventIn( "set_bind" );
      set_bind.setValue( value );

      // send the event to the ProximitySensor enabled exposedField

      // set_bind = (SFBool) viewpoint.getExposedField( "enabled" );
      // set_bind.setValue( value );

      // set the value of the GeoViewpoint isBound eventOut

      isBound.setValue( value );

      // set the value of the GeoViewpoint bindTime eventOut

      bindTime.setValue( e.getTimeStamp() );
    }

    // set a new position for the GeoViewpoint node, and then
    // recalculate the local orientation frame

    if ( e.getName().equals( "set_position" ) ) {
      ConstSFString csfstring = (ConstSFString) e.getValue();
      SFString sfstring = new SFString( csfstring.getValue() );
      process_position( sfstring );
      process_orientation( last_rot );
    }

    // set a new orientation for the GeoViewpoint node, 
    // relative to the local orientation frame

    if ( e.getName().equals( "set_orientation" ) ) {
      float rots[] = new float[4];
      ((ConstSFRotation) e.getValue()).getValue( rots );
      SFRotation sfrot = new SFRotation( rots[0], rots[1], rots[2], rots[3] );
      process_orientation( sfrot );
    }

    // update the NavigationInfo fields for the new camera position
    // (currently disabled in the .wrl file due to Cosmo behaviour)

    if ( e.getName().equals( "position_changed" ) ) {
      float vec3f[] = new float[3];
      ((ConstSFVec3f) e.getValue()).getValue( vec3f );
      new_camera( (double) vec3f[0], (double) vec3f[1], (double) vec3f[2] );
    }

  }

  //
  // processEvents overrides the default method because we need
  // to make sure that we process an set_position eventIns before
  // we process a set_orientation eventIn (because the orientation is
  // relative to a local orientation frame defined by the position).
  //

  public void processEvents( int count, Event events[] ) {

    // process any position eventIns first as these will define
    // the local coordinate system for any orientation eventIns
    // (currently this is moot as we don't support set_position)

    for ( int i = 0; i < count; i++ ) {
      if ( events[i].getName().equals( "set_position" ) )
	processEvent( events[i] );
    }

    // Now we can process all of the other events

    for ( int i = 0; i < count; i++ ) {
      if ( ! events[i].getName().equals( "set_position" ) )
	processEvent( events[i] );
    }

  }

  //
  // The initialize method is called when the Node is first loaded.
  // Here we grab copies of any necessary fields/eventIn/eventOuts
  //

  public void initialize() {

    // Take copies of all the fields for this node

    SFNode     geoOrigin     = (SFNode) getField( "geoOrigin" );
    SFString   sfposition    = (SFString) getField( "position" );
    SFRotation sforientation = (SFRotation) getField( "orientation" );

    geoSystem   = (MFString) getField( "geoSystem" );
    viewpoint   = (Node) ((SFNode) getField( "viewpoint" )).getValue();
    navinfo     = (Node) ((SFNode) getField( "navinfo" )).getValue();
    speed_scale = ((SFFloat) getField( "speed" )).getValue();
    debug       = ((SFBool) getField( "debug" )).getValue();
    // proxsensor  = (Node) ((SFNode) getField( "proxsensor" )).getValue();

    isBound     = (SFBool) getEventOut( "isBound" );
    bindTime    = (SFTime) getEventOut( "bindTime" );

    if ( debug ) System.out.println( "GeoViewpoint:" );

    // Okay, let's initialise the GeoVRML utility class
    // These classes should be installed on the user's system and in
    // their CLASSPATH. If they are not, then we can't do anything!

    try {
      geovrml = new GeoVRML();
    } catch ( NoClassDefFoundError e ) {
      System.out.println( "GeoTransform classes not installed in CLASSPATH!" );
      return;
    }

    geovrml.setOrigin( geoOrigin );

    // set the default viewpoint position

    process_position( sfposition );

    // and set the default viewpoint orientation relative to this LCS

    process_orientation( sforientation );

    // set the initial navigation speed and near/far clipping planes

    new_camera( gcc.x, gcc.y, gcc.z );

    // bind the new viewpoint and navigation nodes for the first
    // node loaded

    if ( firstInstance == true ) {
	firstInstance = false;

        ((SFBool) viewpoint.getEventIn( "set_bind" )).setValue( true );
        ((SFBool) navinfo.getEventIn( "set_bind" )).setValue( true );

        isBound.setValue( true );
    }

  }

}

// EOF: GeoViewpoint.java
