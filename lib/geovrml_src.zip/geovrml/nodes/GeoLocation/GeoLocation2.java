//
// Filename: GeoLocation.java
//
// Authors:
//   Martin Reddy, SRI International - 21 August 1999
//   John Brecht, SRI Internation - 31 March 2000
//
// Purpose:
//   This class implements a new Transform node for VRML. It allows you
//   to take any arbitrary VRML context and geo-reference it, i.e. place
//   it at a specific point on the planet.
//
//   This code requires access to the GeoTransform Java package, included
//   as part of the GeoVRML source code distribution.
//
// License:
//   The contents of this file are subject to GeoVRML Public License
//   Version 1.0 (the "License"); you may not use this file except in
//   compliance with the License. You may obtain a copy of the License at
//   http://www.geovrml.org/1.0/license/.
//
//   Software distributed under the License is distributed on an "AS
//   IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
//   implied. See the License for the specific language governing
//   rights and limitations under the License.
//
//   Portions are Copyright (c) SRI International, 2000.
//
// Revision:
//  $Id: GeoLocation2.java,v 1.1 2002/07/15 01:30:08 reddy Exp $
//
//  Martin Reddy (21 Aug 1999) - initial version
//  John Brecht (31 Mar 2000) - support set_geoCoords eventIn
//

import java.lang.*;
import vrml.*;
import vrml.field.*;
import vrml.node.*;
import geotransform.coords.Gcc_Coord_3d;
import org.web3d.geovrml.GeoVRML;

public class GeoLocation2 extends Script {

  MFString geoSystem;
  SFNode geoOrigin;
  GeoVRML geovrml;
  Node transform;
  boolean debug;
  SFString geoCoords_changed;


  // process the set_geoCoords eventIn by calling updateGeoCoords()
  // and produce the geoCoords_changed eventOut.


  public void processEvent( Event e ) {


    String name = e.getName();

    if ( debug ) System.out.println( "Event received: " + name );

    if ( name.equals( "set_geoCoords" ) ) {
      ConstSFString csfstring = (ConstSFString) e.getValue();
      SFString sfstring = new SFString( csfstring.getValue() );
      updateGeoCoords(sfstring);
      geoCoords_changed.setValue(sfstring);
    }
  }


  // The initialize method is called when the Node is first loaded.
  // Here we grab copies of any necessary fields/eventIn/eventOuts
  // and do the coordinate transformation in order to find the
  // correct geolocation for the transform's childrens.

  public void initialize() {

    // Take copies of all the fields for this node

    geoOrigin   = (SFNode) getField( "geoOrigin" );
    geoSystem = (MFString) getField( "geoSystem" );
    transform     = (Node) ((SFNode) getField( "transform" )).getValue();
    debug      = ((SFBool) getField( "debug" )).getValue();
    geoCoords_changed = (SFString) getEventOut( "geoCoords_changed" );

    Node def_coords = (Node) ((SFNode) getField( "def_coords" )).getValue();
    SFString geoCoords = (SFString) def_coords.getExposedField( "description" );

    if ( debug ) System.out.println( "GeoLocation:" );

    // Okay, let's initialise the GeoVRML utility class
    // These classes should be installed on the user's system and in
    // their CLASSPATH. If they are not, then we can't do anything!

    try {
      geovrml = new GeoVRML();
    } catch ( NoClassDefFoundError e ) {
      System.out.println( "GeoTransform classes not installed in CLASSPATH!" );
      return;
    }

    geovrml.setOrigin( geoOrigin );

    updateGeoCoords(geoCoords);

  }

    // Converts the inputed geoCoords to GCC and sets the transform
    // of the Node appropriately.

  public void updateGeoCoords(SFString geoCoords) {
    // Find out the location that the user wants to georeference to
    // This is essentially the translation vector for the transform

    Gcc_Coord_3d gcc = geovrml.getCoord( geoCoords, geoSystem );

    SFVec3f xform_trans = (SFVec3f) transform.getExposedField( "translation" );
    xform_trans.setValue( (float) gcc.x, (float) gcc.y, (float) gcc.z );

    if ( debug )
      System.out.println( "  translation = " + gcc.x +" "+ gcc.y +" "+ gcc.z );

    // Now let's work out the orientation at that location in order
    // to maintain a view where +Y is in the direction of gravitional
    // up for that region of the planet's surface. This will be the
    // value of the rotation vector for the transform.

    float orient[] = new float[4];

    geovrml.getLocalOrientation( gcc, orient );

    SFRotation xform_rot = (SFRotation) transform.getExposedField("rotation");
    xform_rot.setValue( orient[0], orient[1], orient[2], orient[3] );

    if ( debug )
      System.out.println( "  rotation = " + orient[0] + " " + orient[1] +
			  " " + orient[2] + " " + orient[3] + " (" +
			  orient[3] * 57.29578f + " deg)" );

    // Finally, we can set the scale field of the transform based
    // upon the global GeoVRML class scaleFactor.

    SFVec3f xform_scale = (SFVec3f) transform.getExposedField( "scale" );
    float   scale = (float) ( 1.0 / geovrml.scaleFactor );
    xform_scale.setValue( scale, scale, scale );
  }
}

// EOF: GeoLocation.java
