//
// Filename: GeoTouchSensor.java
//
// Author:
//	 John Brecht, SRI International.
//
// Purpose:
//	 This class appends the ability to ouput in geographic coordinates
//	 to the existing eventOuts of a normal TouchSensor
//
//	 This code requires access to the GeoTransform Java package, included
//	 as part of the GeoVRML source code distribution.
//
// License:
//	 The contents of this file are subject to GeoVRML Public License
//	 Version 1.0 (the "License"); you may not use this file except in
//	 compliance with the License. You may obtain a copy of the License at
//	 http://www.geovrml.org/1.0/license/.
//
//	 Software distributed under the License is distributed on an "AS
//	 IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
//	 implied. See the License for the specific language governing
//	 rights and limitations under the License.
//
//	 Portions are Copyright (c) SRI International, 2000.
//
//

import java.lang.*;
import vrml.*;
import vrml.field.*;
import vrml.node.*;

import geotransform.coords.*;
import geotransform.ellipsoids.*;
import geotransform.transforms.*;
import org.web3d.geovrml.GeoVRML;


public class GeoTouchSensor extends Script {

	SFVec3f	hitNormal_changed;
	SFVec3f	hitPoint_changed;
	SFString hitGeoCoord_changed;
	SFVec2f	hitTexCoord_changed;
	SFBool	 isActive;
	SFBool	 isOver;
	SFTime	 touchTime;
	String	 geo_system = null;
	boolean	debug = false;
	GeoVRML	geovrml = null;

	// The processEvent method gets called when the TouchSensor
	// events are triggered.  All the events are sent right back
	// out as-is, except hitPoint_changed also causes the new
	// hitGeoCoord_changed event to go out.  The value of the
	// geoCoord is calculated byt the geoCoord() method below.

	public void processEvent( Event e ) {

		String name = e.getName();
		Object value = e.getValue();

		if ( debug ) System.out.println( "Event received: " + name );

		if ( name.equals( "TS_hitNormal_changed" ) ) {
			hitNormal_changed.setValue((ConstSFVec3f)value);
		}
		else if ( name.equals( "TS_hitPoint_changed" ) ) {
			hitPoint_changed.setValue((ConstSFVec3f)value);
			hitGeoCoord_changed.setValue(geovrml.geoCoord((ConstSFVec3f)value, geo_system));
		}
		else if ( name.equals( "TS_hitTexCoord_changed" ) ) {
			hitTexCoord_changed.setValue((ConstSFVec2f)value);
		}
		else if ( name.equals( "TS_isActive" ) ) {
			isActive.setValue((ConstSFBool)value);
		}
		else if ( name.equals( "TS_isOver" ) ) {
			isOver.setValue((ConstSFBool)value);
		}
		else if ( name.equals( "TS_touchTime" ) ) {
			touchTime.setValue((ConstSFTime)value);
		}


	}

	// The initialize method is called when the Node is first loaded.
	// Here we grab copies of any necessary fields/eventIn/eventOuts
	// and initialize the GeoVRML object

	public void initialize() {

		// Take copies of all the fields for this node

		SFNode geoOrigin		= (SFNode) getField( "geoOrigin" );
		MFString geoSystem	= (MFString) getField( "geoSystem" );
		debug							 = ((SFBool) getField( "debug" )).getValue();
		hitNormal_changed	 = (SFVec3f) getEventOut( "hitNormal_changed" );
		hitPoint_changed		= (SFVec3f) getEventOut( "hitPoint_changed");
		hitTexCoord_changed = (SFVec2f) getEventOut( "hitTexCoord_changed");
		hitGeoCoord_changed = (SFString) getEventOut( "hitGeoCoord_changed" );
		isActive						= ((SFBool) getEventOut( "isActive" ));
		isOver							= ((SFBool) getEventOut( "isOver" ));
		touchTime					 = ((SFTime) getEventOut( "touchTime" ));


		if ( debug ) System.out.println( "GeoTouchSensor:" );


		// Okay, let's initialise the GeoVRML utility class
		// These classes should be installed on the user's system and in
		// their CLASSPATH. If they are not, then we can't do anything!

		try {
			geovrml = new GeoVRML();
		} catch ( NoClassDefFoundError e ) {
			System.out.println( "GeoTransform classes not installed in CLASSPATH!" );
			return;
		}

		if ( debug ) System.out.println( "about to setOrigin" );
			geovrml.setOrigin( geoOrigin );
		if ( debug ) System.out.println( "done setOrigin" );
			geo_system = geovrml.VRMLToString( geoSystem );
		if ( debug ) System.out.println( "done writing geosystem" );

		if ( debug ) {
			System.out.println( "GeoSystem:" + geo_system );
		}

	}

}

// EOF: GeoTouchSensor.java
