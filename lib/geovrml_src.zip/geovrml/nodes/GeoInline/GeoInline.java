//
// Filename: GeoInline.java
//
// Author:
//   Martin Reddy, SRI International - 5 November 1999.
//
// Purpose:
//   This class implements a new Inline node for VRML. It aims to provide
//   the same basic functionality as the built-in Inline node, but offers
//   control over when the file to be inlined should be loaded, both
//   statically (in the VRML code) and dynamically (via events passed into
//   the node). Functionality is also available to unload an already
//   inlined file. In addition, the GeoInline node exposes the scene graph
//   for the inlined file so that this can be accessed by external APIs
//   such as the EAI.
//
// License:
//   The contents of this file are subject to GeoVRML Public License
//   Version 1.0 (the "License"); you may not use this file except in
//   compliance with the License. You may obtain a copy of the License at
//   http://www.geovrml.org/1.0/license/.
//
//   Software distributed under the License is distributed on an "AS
//   IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
//   implied. See the License for the specific language governing
//   rights and limitations under the License.
//
//   Portions are Copyright (c) SRI International, 2000.
//
// Revision:
//  $Id: GeoInline.java,v 1.2 2002/03/12 19:49:20 reddy Exp $
//

import vrml.*;
import vrml.field.*;
import vrml.node.*;

public class GeoInline extends Script {
  
  // Java versions of the Script's fields and eventOuts
   
  private Node     group;              // field
  private MFNode   children;           // eventOut
  private MFString url_changed;        // eventOut
  private SFBool   load_changed;       // eventOut
  private MFNode   empty_node;         // field

  // Internal state variables

  private String[] url;                // field
  private boolean  load;               // field
  private boolean  debug;              // field
  private Browser  browser = null;

  private boolean  isloading = false;

  // The initiate_load() method is used to load the scene for the
  // GeoInline. It uses the Browser method createVrmlFromURL to
  // perform this. Once the scene has been loaded, a nodesLoaded
  // eventIn is sent to the processEvent() method below.

  public synchronized void initiate_load() {
    if ( browser != null ) {

      try {
	browser.createVrmlFromURL( url, this, "nodesLoaded" );
      } catch ( InvalidVRMLSyntaxException e ) {
	System.out.println( "Couldn't Inline file: invalid VRML syntax" );
	return;
      }

      isloading = true;

      if ( debug ) System.out.println( "Loading " + url[0] );

    } else
      System.out.println( "Browser object not found" );
  }

  // The initialize method is called when the Node is first loaded.
  // Here we grab copies of any necessary fields/eventIn/eventOuts
  // and fire off initial values for the eventOuts.

  public void initialize() {

    // Take copies of all the fields for this node

    group             = (Node) ((SFNode) getField( "group" )).getValue();
    children          = (MFNode) getEventOut( "children" );
    MFString geo_url  = (MFString) getField( "geourl" );
    url_changed       = (MFString) getEventOut( "url_changed" );
    load              = ((SFBool) getField( "load" )).getValue();
    load_changed      = (SFBool) getEventOut( "load_changed" );
    debug             = ((SFBool) getField( "debug" )).getValue();

    // get a convenience object for the inline file's URL

    url = new String[geo_url.getSize()];
    geo_url.getValue( url );

    // create an empty node that we send out as the children MFNode
    // of GeoInline whenever a load=FALSE is performed.

    empty_node = new MFNode();

    // Grab the VRML Browser object

    browser = getBrowser();

    // Initialise any eventOuts to default values

    children.setValue( empty_node );
    url_changed.setValue( url );
    load_changed.setValue( load );

    // load the inline on startup if the load field is set to TRUE

    if ( load == true ) initiate_load();
  }

  // Load the inline scene, if it is not already loaded
  // or in the process of being loading

  public void loadUrl() {
    if ( load == false && isloading == false )
      initiate_load();
  }

  // Remove the current inline nodes from the scene, if loaded

  public void unloadUrl() {
    if ( load == true ) {

      MFNode rc = (MFNode) group.getEventIn( "removeChildren" );
      rc.setValue( (ConstMFNode) group.getEventOut( "children" ) );
      children.setValue( empty_node );
      load = false;
      load_changed.setValue( false );

      if ( debug ) System.out.println( "Unloading "+url[0] );
    }
  }

  // The shutdown method is called when this object is destroyed

  public void shutdown() {
    unloadUrl();
  }

  // Handle all of the eventIn's that we support....

  public synchronized void processEvent( Event e ) {
    String event_name = e.getName();

    if ( debug ) System.out.println( "Event received: " + event_name );

    if ( event_name.equals( "set_load" ) ) {

      // The set_load eventIn is used to load or unload the nodes
      // for the Inline from the scene graph. Checks are made so
      // that we don't try to load a file if it is already loaded
      // and we don't try to unload a file if there is no file loaded
    
      boolean new_load = ((ConstSFBool) e.getValue()).getValue();
      
      if ( load != new_load ) {
	if ( new_load == true ) {
	  loadUrl();
	} else {
	  unloadUrl();
	}
      }
      
    } else if ( event_name.equals( "set_url" ) ) {

      // The set_url eventIn is used to change the url of the 
      // Inline node and to cause this url to be loaded if the
      // current state of the node is load == true.
      
      ConstMFString mfs = (ConstMFString) e.getValue();
      String[] new_url = new String[mfs.getSize()];
      mfs.getValue( new_url );
      
      if ( load == true ) {
	unloadUrl();
	url = new_url;
	loadUrl();
      } else {
	url = new_url;
      }

      url_changed.setValue( new_url );
      
    } else if ( event_name.equals( "nodesLoaded" ) ) {

      // The nodesLoaded event is only used within this object.
      // It is called by createVrmlFromURL when it has completed
      // the loading of the Inline url file
      
      ConstMFNode new_nodes = (ConstMFNode) e.getValue();

      if ( new_nodes == null || new_nodes.getSize() == 0 ) {

        // failure might be due to a file not found, but also
        // due to relative URL funkiness - relative URLs should
        // resolve with respect to the PROTO file location which
        // could be on local disk - best to use absolute URLs

        if ( debug ) System.out.println( "Could not load URL!" );

        load = false;
        isloading = false;

      } else {

        MFNode ac = (MFNode) group.getEventIn( "addChildren" );
        ac.setValue( new_nodes );

        children.setValue( new_nodes );

        load = true;
        isloading = false;
        load_changed.setValue( true );

      }
    }
    
    
  }
}

// EOF: GeoInline.java
