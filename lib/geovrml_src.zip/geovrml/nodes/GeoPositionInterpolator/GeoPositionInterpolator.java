//
// Filename: GeoPositionInterpolator.java
//
// Author:
//   Martin Reddy, SRI International.
//
// Purpose:
//   This class implements a new PositionInterpolator node for VRML.
//   It enables the specification of coordinates in coordinate systems
//   other than the basic VRML Cartesian XYZ system. We support a number
//   of geographic coordinate systems such as lat/long and UTM.
//
//   This code requires access to the GeoTransform Java package, included
//   as part of the GeoVRML source code distribution.
//
// License:
//   The contents of this file are subject to GeoVRML Public License
//   Version 1.0 (the "License"); you may not use this file except in
//   compliance with the License. You may obtain a copy of the License at
//   http://www.geovrml.org/1.0/license/.
//
//   Software distributed under the License is distributed on an "AS
//   IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
//   implied. See the License for the specific language governing
//   rights and limitations under the License.
//
//   Portions are Copyright (c) SRI International, 2000.
//
// Revision:
//   $Id: GeoPositionInterpolator.java,v 1.1.1.1 2000/06/15 16:49:27 reddy Exp $
//

import java.lang.*;
import vrml.*;
import vrml.field.*;
import vrml.node.*;
import geotransform.coords.Gcc_Coord_3d;
import org.web3d.geovrml.GeoVRML;

public class GeoPositionInterpolator extends Script {
  
  SFVec3f  value_changed = null;
  SFString geovalue_changed = null;
  String   keyValue[] = null;
  int      keyValueSize = 0;
  float    key[] = null;
  int      keySize = 0;
  String   geo_system = null;
  boolean  debug = false;
  GeoVRML  geovrml = null;

  // The processEvent method gets called when a set_fraction event
  // is received. This is where we do all of the work to calculate
  // the interpolation. N.B. we interpolate in the actual geographic
  // coordinate system.

  public void processEvent( Event e ) {
    float        fraction = ((ConstSFFloat) e.getValue()).getValue();
    int          index = 0;
    String       value;
    Gcc_Coord_3d gcc;

    if ( debug ) System.out.println( "  got fraction " + fraction );

    // do we actually have anything to interpolate over?

    if ( keySize < 1 ) return;
    
    // do we have the case: f(t) = v0 if t < t0

    if ( fraction <= key[0] || keySize < 2 ) {
      value = keyValue[0];
      if ( debug ) System.out.println( "  first value = " + value );
    }

    // do we have the case: f(t) = vn-1 if t > tn-1

    else if ( fraction >= key[keySize-1] ) {
      value = keyValue[keySize-1];
      if ( debug ) System.out.println( "  last value = " + value );
    }

    // otherwise, we need to do an interpolation
    
    else {

      // find the two keyValues to interpolate over, ti <= t <= ti+1

      int i;
      for ( i = 0; i < keySize-1; i++ ) {
	if ( fraction <= key[i+1] )
	  break;
      }

      // normalise the fraction to be 0->1 between ti -> ti+1

      float perc = ( fraction - key[i] ) / ( key[i+1] - key[i] );

      if ( debug ) System.out.println( "  linterp index = " + i );

      // do the linear interpolation

      value = geovrml.linterp( keyValue[i], keyValue[i+1], perc, geo_system );

      if ( debug ) System.out.println( "  linterp value = " + value );
    }
    
    // now we can convert the geographic coord string to an (x,y,z)
    
    gcc = geovrml.getCoord( value, geo_system );

    // this is the output of the value_changed eventOut
    
    value_changed.setValue( (float) gcc.x, (float) gcc.y, (float) gcc.z );

    if ( debug ) System.out.println( "  output = " + gcc.x + ", " + gcc.y 
				     + ", " + gcc.z );

    // also output the geographic coordinate string for
    // piping into GeoVRML nodes that support this

    geovalue_changed.setValue( value );

  }

  // The initialize method is called when the Node is first loaded.
  // Here we grab copies of any necessary fields/eventIn/eventOuts
  // and initialize the GeoVRML object

  public void initialize() {

    // Take copies of all the fields for this node

    SFNode geoOrigin   = (SFNode) getField( "geoOrigin" );
    MFString geoSystem = (MFString) getField( "geoSystem" );
    value_changed      = (SFVec3f) getEventOut( "value_changed" );
    geovalue_changed   = (SFString) getEventOut( "geovalue_changed" );
    debug              = ((SFBool) getField( "debug" )).getValue();

    // get the key array as an array of floats

    if ( debug ) System.out.println( "GeoPositionInterpolator:" );

    MFFloat mfKey = (MFFloat) getField( "key" );
    keySize = mfKey.getSize();
    key = new float[keySize];
    mfKey.getValue( key );

    if ( debug ) System.out.println( "  got key array" );

    // get the keyValue array as an array of strings

    MFString mfKeyValue = (MFString) getField( "keyValue" );
    keyValueSize = mfKeyValue.getSize();
    keyValue = new String[keyValueSize];
    mfKeyValue.getValue( keyValue );

    if ( debug ) System.out.println( "  got keyValue array" );

    // Okay, let's initialise the GeoVRML utility class
    // These classes should be installed on the user's system and in
    // their CLASSPATH. If they are not, then we can't do anything!

    try {
      geovrml = new GeoVRML();
    } catch ( NoClassDefFoundError e ) {
      System.out.println( "GeoTransform classes not installed in CLASSPATH!" );
      return;
    }

    geovrml.setOrigin( geoOrigin );
    geo_system = geovrml.VRMLToString( geoSystem );

  }

}

// EOF: GeoPositionInterpolator.java
