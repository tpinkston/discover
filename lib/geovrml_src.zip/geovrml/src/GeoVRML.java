//
// Filename: GeoVRML.java
//
// Authors:
//   Martin Reddy, SRI International
//   Heiko Grussbach, Centre Recherche Henri Tudor
//   John Brecht, SRI International
//
// Purpose:
//   This class provides a set of useful functions that are used by
//   a number of the nodes developed by the GeoVRML Working Group.
//   These nodes are defined by the GeoVRML Coordinate System RFC
//   at <http://www.geovrml.org/rfc1.shtml>. This class is
//   used to implement the support for geographic coordinate systems
//   for nodes such as GeoLocation, GeoCoordinate, and so on.
//
// License:
//   The contents of this file are subject to GeoVRML Public License
//   Version 1.0 (the "License"); you may not use this file except in
//   compliance with the License. You may obtain a copy of the License at
//   http://www.geovrml.org/1.0/license/.
//
//   Software distributed under the License is distributed on an "AS
//   IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
//   implied. See the License for the specific language governing
//   rights and limitations under the License.
//
//   Portions are Copyright (c) SRI International, 2000.
//
// Revisions:
//   Martin Reddy (18 Jan 1999): first version
//   John Brecht (1 Mar 2000): added support for GeoTouchSensor
//   Heiko Grussbach (28 Feb 2000): optimized GeoElevationGrid routines
//
//   $Id: GeoVRML.java,v 1.2 2002/07/15 01:30:08 reddy Exp $
//
// Class Hierarchy:
//
//    GeoVRML
//      |
//      +-- getVersion()                             returns a version string
//      |
//      +-- setOrigin(String,String)                       sets the geoOrigin
//      |   setOrigin(SFNode)
//      |
//      +-- getOrigin()                       returns current value of origin
//      |
//      +-- getCoord(String,String)           convert single geocentric coord
//      |   getCoord(SFString,MFString)
//      |   getCoord(MFString,MFString)
//      |
//      +-- geoCoord(float[],String)     convert single GC coord to UTM or GD
//      |   geoCoord(SFVec3f,String)
//      |   geoCoord(SFVec3f,MFString)
//      |   geoCoord(float[],MFString)
//      |
//      +-- getCoords(String,String)        convert list of geocentric coords
//      |   getCoords(SFString,MFString)
//      |   getCoords(MFString,MFString)
//      |
//      +-- addCoord(String,double,double,double,String)  add offset to coord
//      |
//      +-- getLocalOrientation(Gcc_Coord_3d,float[4])  calculate LVCS orient
//      |   getLocalOrientation(Gdc_Coord_3d,float[4])
//      |
//      +-- getElevation(double,double,double)        calc height above earth
//      |
//      +-- VRMLToString(MFString)                         MFString -> String
//      |   VRMLToString(SFString)                         SFString -> String
//      |
//      +-- linterp(String,String,float,String)          linear interpolation
//      |
//      +-- scaleFactor                            every coord /= scaleFactor
//
// Distribution:
//   This material is published in the spirit of Open Source.
//   You can use or distribute this material freely. You cannot sell it.
//   If you add something cool, then please let me know so that it
//   can be merged into a future release. The GeoVRML distribution
//   can be found from http://www.geovrml.org/1.0/
//
//   Portions are Copyright (c) SRI International, 1999.
//

package org.web3d.geovrml;

// import all the relevant Java, VRML, and GeoTransform classes

import java.lang.*;
import java.util.Vector;
import vrml.*;
import vrml.field.*;
import vrml.node.*;
import geotransform.ellipsoids.*;
import geotransform.transforms.*;
import geotransform.coords.*;
import org.web3d.geovrml.Quaternion;

public class GeoVRML {

  // some VRML browsers don't cope well with very large numbers, such
  // as GC coordinates. This scale factor is applied to every coord
  // that we pass to VRML in order to make the earth appear to cover
  // an area in the order of several meters rather than several
  // million meters.

  public double scaleFactor = 1.0; // 3000000.0;

  // Remember the GeoOrigin node definition that we have been given

  private Gcc_Coord_3d geo_origin = null;

  // Parser to reuse in repeated calls to getCoord(double[], String) [Heiko]

  private CoordParser coord_parser = null;

  //
  // GeoVRML.getVersion()
  //
  // Returns a version string for this release of the GeoVRML class
  //

  public String getVersion() { return "1.0"; }

  //
  // GeoVRML.setOrigin( String geoCoords, String geoSystem )
  //
  // This method will take two strings and set the internal value
  // of the geoOrigin for this class. The first string contains
  // the coordinate of the origin in some geographics coordinate
  // system (e.g. "-100 45 0" in lat/long/elev), and the second
  // string defines that coordinate system (e.g. "GD" for lat/
  // long). Method returns false if an error occurred.
  //
  // If you specify a geoOrigin, then its geocentric value will
  // be subtracted from all of the geocentric values that are
  // returned by the getCoord and getCoords methods.
  //

  public boolean setOrigin( String geoCoords, String geoSystem ) {

    if ( geoSystem == null || geoCoords == null ) return false;

    // Okay, let's convert this value into a geocentric coordinate
    // And store it as our GeoOrigin for this instance

    CoordParser parser = new CoordParser( geoCoords, geoSystem );
    geo_origin = parser.getNextCoord();

    return ( geo_origin != null );
  }

  //
  // GeoVRML.setOrigin( SFNode )
  //
  // An overloaded version of the above setOrigin method. This
  // version accepts the SFNode object for a VRML GeoOrigin node.
  // This must have geoSystem and geoCoords fields.
  //

  public boolean setOrigin( SFNode geoOrigin ) {

    // Check that we have a valid GeoOrigin node specified

    if ( geoOrigin == null ) return false;

    // Get the geoSystem and geoCoords fields of the GeoOrigin node

    Node node = (Node) geoOrigin.getValue();

    if ( node == null ) return false;

    MFString tmpSystem;
    SFString tmpCoords;

    try {
      tmpSystem = (MFString) node.getExposedField( "geoSystem" );
    } catch ( InvalidExposedFieldException e ) {
      System.out.println( "No exposedField geoSystem in GeoOrigin node" );
      return false;
    }

    try {
      tmpCoords = (SFString) node.getExposedField( "geoCoords" );
    } catch ( InvalidExposedFieldException e ) {
      System.out.println( "No exposedField geoCoords in GeoOrigin node" );
      return false;
    }

    if ( tmpSystem == null || tmpCoords == null ) return false;

    return setOrigin( VRMLToString( tmpCoords ), VRMLToString( tmpSystem ) );
  }

  //
  // GeoVRML.getOrigin()
  //
  // Returns the currently set geoOrigin for this object, i.e. as set
  // by setOrigin. The value returned will be in earth-fixed geocentric
  // coordinates. If you have not called setOrigin yet, this will be null
  //

  public Gcc_Coord_3d getOrigin() {
    return geo_origin;
  }

  //
  // GeoVRML.getCoord( String, String )
  // GeoVRML.getCoord( SFString, MFString )
  // GeoVRML.getCoord( MFString, MFString )
  //
  // This method will take two strings and return the earth-fixed
  // geocentric coordinate that these represent. The first string
  // contains the coordinate of the origin in some geographic
  // coordinate system (e.g. "-100 45 0" in lat/long/elev), and
  // the second string defines that coordinate system (e.g. "GD"
  // for lat/long). Method returns null if an error occurred.
  //

  public Gcc_Coord_3d getCoord( String geoCoords, String geoSystem ) {
    if ( geoCoords == null || geoSystem == null ) return null;

    CoordParser parser = new CoordParser( geoCoords, geoSystem );

    Gcc_Coord_3d gcc = parser.getNextCoord();
    applyOrigin( gcc );

    return gcc;
  }

  public Gcc_Coord_3d getCoord( SFString geoCoords, MFString geoSystem ) {
    return getCoord( VRMLToString( geoCoords ), VRMLToString( geoSystem ) );
  }

  public Gcc_Coord_3d getCoord( MFString geoCoords, MFString geoSystem ) {
    return getCoord( VRMLToString( geoCoords ), VRMLToString( geoSystem ) );
  }

  //
  // New method, avoids creating a new Parser for each method call, just
  // reuses the old one that is created at the first call of the method
  // [Heiko]
  //

  public Gcc_Coord_3d getCoord(double[] geoCoords,String geo_system) {
    if ((geoCoords==null)||(geo_system==null)) return null;
    if (coord_parser==null) {
      coord_parser = new CoordParser (geo_system);
    }
    Gcc_Coord_3d gcc = coord_parser.getNextCoord(geoCoords);
    applyOrigin( gcc );

    return gcc;
  }

  //
  // GeoVRML.getCoords( String, String )
  // GeoVRML.getCoords( SFString, MFString )
  // GeoVRML.getCoords( MFString, MFString )
  //
  // This method will take two strings and returns an array of
  // earth-fixed geocentric coordinate that are converted from this
  // representation. The first string contains a list of coordinate
  // tuples (e.g. "-100 45 0, -101 46 0" in lat/long/elev), and
  // the second string defines that coordinate system (e.g. "GD"
  // for lat/long). Method returns null if an error occurred.
  // N.B. You can use the length array method to find the number of
  // coordinates in the array once it has been returned.
  //

  public Gcc_Coord_3d[] getCoords( String geoCoords, String geoSystem ) {
    if ( geoCoords == null || geoSystem == null ) return null;

    Vector vector = new Vector( 256, 256 );  // init capacity and increment

    CoordParser parser = new CoordParser( geoCoords, geoSystem );

    // Translate each coordinate in the list

    while ( ! parser.isDone() ) {
      Gcc_Coord_3d gcc = parser.getNextCoord();
      if ( gcc != null ) {
	applyOrigin( gcc );
	vector.addElement( gcc );
      }
    }

    if ( vector.size() <= 0 ) return null;

    // Now put these into a static array to be returned

    Gcc_Coord_3d array[] = new Gcc_Coord_3d[vector.size()];

    for ( int i = 0; i < vector.size(); i++ )
      array[i] = (Gcc_Coord_3d) vector.elementAt(i);

    vector = null; // finished with this: ready for garbage collection

    return array;
  }

  public Gcc_Coord_3d[] getCoords( SFString geoCoords, MFString geoSystem ) {
    return getCoords( VRMLToString( geoCoords ), VRMLToString( geoSystem ) );
  }

  public Gcc_Coord_3d[] getCoords( MFString geoCoords, MFString geoSystem ) {
    return getCoords( VRMLToString( geoCoords ), VRMLToString( geoSystem ) );
  }

  //  public String geoCoord(float[] vals, String geoSystem)
  //  public String geoCoord(ConstSFVec3f gccVec3f, String geoSystem)
  //  public String geoCoord(ConstSFVec3f gccVec3f, MFString geoSystem)
  //  public String geoCoord(float[] vals, MFString geoSystem)
  //
  // Receives GC coordinates and a GeoSystem and returns those coords
  // transformed into the GeoSystem.
  
  public String geoCoord(float[] vals, String geoSystem) {
    if ( geoSystem.trim().equals("GDC") || geoSystem.trim().equals("GD") ) {
      return getGD( vals, geoSystem );
    } else {
      return getUTM( vals, geoSystem );
    }
  }

  public String geoCoord(ConstSFVec3f gccVec3f, String geoSystem) {
    float[] vals = new float[3];
    gccVec3f.getValue(vals);
    return geoCoord(vals, geoSystem);
  }
  public String geoCoord(ConstSFVec3f gccVec3f, MFString geoSystem) {
    float[] vals = new float[3];
    gccVec3f.getValue(vals);
    return geoCoord(vals, VRMLToString( geoSystem ));
  }
  public String geoCoord(float[] vals, MFString geoSystem) {
    return geoCoord(vals, VRMLToString( geoSystem ));
  }

  //  Given an array of floats, which are GC coordinates, computes their GD
  //  equivalent based on the current ellipsoid and returns it.
  
  private String getGD( float[] coords, String geoSystem ) {

    // convert a transformed VRML coordinate into true GC
    Gcc_Coord_3d tmp_gcc = new Gcc_Coord_3d( (double)coords[0],
					     (double)coords[1],
					     (double)coords[2] );
    retractOrigin( tmp_gcc );
    
    // Transform GC to GD
    Gdc_Coord_3d gdc = new Gdc_Coord_3d();
    Gcc_To_Gdc_Converter converter = new Gcc_To_Gdc_Converter();
    converter.Init(parseEllipsoid(geoSystem));
    converter.Convert( tmp_gcc, gdc );

    String gdcString = ""+ gdc.latitude + " " + gdc.longitude + " " +
                       gdc.elevation;
    return gdcString;
  }

  //  Given an array of floats, which are GC coordinates, computes their UTM
  //  equivalent based on the current ellipsoid and returns it.
  
  private String getUTM( float[] coords, String geoSystem ) {
    
    // convert a transformed VRML coordinate into true GC
    Gcc_Coord_3d tmp_gcc = new Gcc_Coord_3d( coords[0], coords[1], coords[2] );
    retractOrigin( tmp_gcc );
    
    // Transform GC to UTM
    Utm_Coord_3d utm = new Utm_Coord_3d();
    Gcc_To_Utm_Converter converter = new Gcc_To_Utm_Converter();
    converter.Init(parseEllipsoid(geoSystem));
    converter.Convert( tmp_gcc, utm );

    String utmString = ""+ utm.y + " " + utm.x + " " + utm.z;
    return utmString;
  }

  // Applies the current geoOrigin to a geocentric value.
  // This just involves subtracting out the origin value.
  // We also implement the world scale factor here.
  // This operation is applied to all coordinates returned
  // to the client, e.g. getCoord and getCoords.

  private void applyOrigin( Gcc_Coord_3d gcc ) {

    if ( geo_origin != null ) {
      gcc.x -= geo_origin.x;
      gcc.y -= geo_origin.y;
      gcc.z -= geo_origin.z;
    }

    if ( scaleFactor != 1.0 && scaleFactor != 0.0 ) {
      gcc.x /= scaleFactor;
      gcc.y /= scaleFactor;
      gcc.z /= scaleFactor;
    }

  }

  // You can get back the original GC coordinates for
  // a point by reversing the applyOrigin operation.
  // This is only useful if you need to know that
  // actual GC coordinate, rather than the render
  // frame coordinate. N.B. This will only work if you
  // have not changed the scaleFactor or origin.

  private void retractOrigin( Gcc_Coord_3d gcc ) {

    if ( scaleFactor != 1.0 && scaleFactor != 0.0 ) {
      gcc.x *= scaleFactor;
      gcc.y *= scaleFactor;
      gcc.z *= scaleFactor;
    }

    if ( geo_origin != null ) {
      gcc.x += geo_origin.x;
      gcc.y += geo_origin.y;
      gcc.z += geo_origin.z;
    }

  }

  // parse the Ellipsoid definition from a geoSystem string

  public static Ellipsoid parseEllipsoid( String geoSystem ) {

    if ( geoSystem.indexOf( " AA" ) >= 0 ) return new AA_Ellipsoid();
    else if ( geoSystem.indexOf( " AM" ) >= 0 ) return new AM_Ellipsoid();
    else if ( geoSystem.indexOf( " AN" ) >= 0 ) return new AN_Ellipsoid();
    else if ( geoSystem.indexOf( " BN" ) >= 0 ) return new BN_Ellipsoid();
    else if ( geoSystem.indexOf( " BR" ) >= 0 ) return new BR_Ellipsoid();
    else if ( geoSystem.indexOf( " CC" ) >= 0 ) return new CC_Ellipsoid();
    else if ( geoSystem.indexOf( " CD" ) >= 0 ) return new CD_Ellipsoid();
    else if ( geoSystem.indexOf( " EA" ) >= 0 ) return new EA_Ellipsoid();
    else if ( geoSystem.indexOf( " EB" ) >= 0 ) return new EB_Ellipsoid();
    else if ( geoSystem.indexOf( " EC" ) >= 0 ) return new EC_Ellipsoid();
    else if ( geoSystem.indexOf( " ED" ) >= 0 ) return new ED_Ellipsoid();
    else if ( geoSystem.indexOf( " EE" ) >= 0 ) return new EE_Ellipsoid();
    else if ( geoSystem.indexOf( " FA" ) >= 0 ) return new FA_Ellipsoid();
    else if ( geoSystem.indexOf( " HE" ) >= 0 ) return new HE_Ellipsoid();
    else if ( geoSystem.indexOf( " HO" ) >= 0 ) return new HO_Ellipsoid();
    else if ( geoSystem.indexOf( " IN" ) >= 0 ) return new IN_Ellipsoid();
    else if ( geoSystem.indexOf( " KA" ) >= 0 ) return new KA_Ellipsoid();
    else if ( geoSystem.indexOf( " RF" ) >= 0 ) return new RF_Ellipsoid();
    else if ( geoSystem.indexOf( " SA" ) >= 0 ) return new SA_Ellipsoid();
    else if ( geoSystem.indexOf( " WD" ) >= 0 ) return new WD_Ellipsoid();
    else if ( geoSystem.indexOf( " WE" ) >= 0 ) return new WE_Ellipsoid();

    return new WE_Ellipsoid();
  }


  //
  // GeoVRML.getElevation( double, double, double )
  //
  // Takes a VRML coordinate, as returned by getCoord(s), i.e.
  // it has had an origin and scale applied to it. Returns the
  // user's height above the WGS84 ellipsoid in units of meters.
  //

  public double getElevation( double x, double y, double z ) {

    // convert a transformed VRML coordinate into true GC

    Gcc_Coord_3d tmp_gcc = new Gcc_Coord_3d( x, y, z );

    retractOrigin( tmp_gcc );

    // Transform GC to GD (this is inefficient! We should
    // cache an initialised Gdc_Coord_3d to reduce costs).

    Gdc_Coord_3d gdc = new Gdc_Coord_3d();

    Gcc_To_Gdc_Converter.Init( new WE_Ellipsoid() );
    Gcc_To_Gdc_Converter.Convert( tmp_gcc, gdc );

    // return the elevation of the GD coordinate

    return gdc.elevation;
  }

  //
  // GeoVRML.getLocalOrientation( Gcc_Coord_3d, float[4] )
  // GeoVRML.getLocalOrientation( Gdc_Coord_3d, float[4] )
  //
  // This next method takes a GC or GD coordinate and returns the
  // orientation for a Local Vertical Coordinate System (LVCS)
  // positioned at the corresponding GD coordinate on the
  // earth's elipsoid. That is, it finds the rotation to get
  // into the local coordinate system for a specific location/
  //
  // N.B the GC coordinate is assume to have had the applyOrigin
  // method applied to it, i.e. it is in the render frame, such
  // as getCoord and getCoords returns.
  //
  // orient should be a float[4]. It will be filled such that
  // the first three entries are the (x,y,z) axis, and the
  // fourth entry is the angle (radians), i.e. the order used for
  // SFRotation fields in VRML97.
  //
  // N.B. this method leaves the viewer in a Y-up coordinate frame
  // as used by VRML97. In order to get into a Z-up frame, then
  // use an angle of (90+lat) for the qx.rotation.
  //

  public void getLocalOrientation( Gdc_Coord_3d gdc, float orient[] ) {
    Quaternion   qx = new Quaternion();
    Quaternion   qz = new Quaternion();
    Quaternion   qr = new Quaternion();

    // work out the location coordinate system rotation

    qz.rotation( 0.0, 0.0, 1.0, (90.0 + gdc.longitude) );
    qx.rotation( 1.0, 0.0, 0.0, (180.0 - gdc.latitude) );

    qr.add( qx, qz );

    double axis[] = new double[3];
    double angle = qr.axis_angle( axis );

    // return the answer as a single-precision angle/axis vector

    orient[0] = (float) axis[0];
    orient[1] = (float) axis[1];
    orient[2] = (float) axis[2];
    orient[3] = (float) angle;
  }

  public void getLocalOrientation( Gcc_Coord_3d gcc, float orient[] ) {

    // Create a new GC coordinate and reverse off the applyOrigin method
    // that was done on the coordinate that the client has given us.

    Gcc_Coord_3d tmp_gcc = new Gcc_Coord_3d( gcc.x, gcc.y, gcc.z );

    retractOrigin( tmp_gcc );

    // convert the (modified) GC coordinate to lat/long

    Gdc_Coord_3d gdc = new Gdc_Coord_3d();

    Gcc_To_Gdc_Converter.Init( new WE_Ellipsoid() );
    Gcc_To_Gdc_Converter.Convert( tmp_gcc, gdc );

    // and then pass to the GD routine that does all of the work

    getLocalOrientation( gdc, orient );

  }

  //
  // GeoVRML.addCoord( String, double, double, double, String )
  //
  // Takes an absolute geolocation, specified as a string (abs), along with
  // the information to describe the coorindate system (geo_system), and
  // an (x,z,height) offset. We then compute the new string that describes
  // the coordinate with that offset applied. This only makes sense for
  // surface projections - it doesn't make sense in GC.
  //

  public String addCoord( String abs, double dx, double dz, double height,
			  String geo_system ) {

    // coordinates in all of our coordinate systems are represented
    // using 3 values, so we don't need to worry which coordinate
    // system the string abs is represented in.

    double[] p = getValues( abs,3 );
    p[0] += dz;
    p[1] += dx;
    p[2] += height;

    StringBuffer sb=new StringBuffer();

    sb.append(p[0]);
    sb.append(" ");
    sb.append(p[1]);
    sb.append(" ");
    sb.append(p[2]);

    return sb.toString();
  }

  //
  // GeoVRML.addCoord( double[], double[], double, double, double, String )
  //
  // This method performs the same calculation as the one above, except that
  // it expects a double[] coord argument to put its result in.
  // [Heiko]
  //
  // Takes an absolute geolocation, specified as a double array, along with
  // the information to describe the coordindate system (geo_system), and
  // an (x,z,height) offset. We then compute the new string that describes
  // the coordinate with that offset applied. This only makes sense for
  // surface projections - it doesn't make sense in GC.
  //

  public void addCoord(double[] coord, double[] abs, double dx, double dz,
		       double height, String geo_system ) {

    coord[0] = abs[0] + dz;
    coord[1] = abs[1] + dx;
    coord[2] = abs[2] + height;
  }

  //
  // GeoVRML.linterp( String, String, float, String )
  //
  // Takes two absolute geographic coordinates and a floating point value
  // between 0.0 and 1.0. Then peforms a linear interpolation between the
  // two coordinates. The final string specifes the coordinate system of
  // the two coordinates.
  //

  public String linterp( String coord1, String coord2, float perc,
			 String geo_system ) {

    // linearly interpolate between two coordinates. All coordinates
    // in our coordinate systems are represented using 3 values,
    // so we don't need to worry which coordinate system the strings
    // are represented in.

    double p1 = getNthValue( coord1, 0 );
    double p2 = getNthValue( coord1, 1 );
    double p3 = getNthValue( coord1, 2 );

    double q1 = getNthValue( coord2, 0 );
    double q2 = getNthValue( coord2, 1 );
    double q3 = getNthValue( coord2, 2 );

    double percentage = (double) perc;

    double i1 = p1 + ( q1 - p1 ) * percentage;
    double i2 = p2 + ( q2 - p2 ) * percentage;
    double i3 = p3 + ( q3 - p3 ) * percentage;

    return i1 + " " + i2 + " " + i3;
  }

  // utility function used for addCoord and linterp above

  public double[] getValues(String source,int num) {
    double[] ret=new double[num];
    for (int i=0;i<num;i++) ret[i]=getNthValue(source,i);
    return ret;
  }

  private double getNthValue( String source, int n ) {

    if ( n < 0 ) return 0.0;

    int sub_end = 0, sub_start = 0, len = source.length();

    for ( int i = 0; i <= n; i++ ) {
      sub_start = sub_end;
      while ( sub_start < len && ( source.charAt( sub_start ) <= ' ' ) )
	sub_start++;

      if ( sub_start >= len ) return 0.0;

      sub_end = sub_start + 1;
      while ( sub_end < len && source.charAt( sub_end ) > ' ' )
	sub_end++;
    }

    String nth_string = source.substring( sub_start, sub_end );
    return (Double.valueOf(nth_string)).doubleValue();
  }


  // Convert a VRML MFString field into a Java String.
  // We should be able to do this with mf_string.toString(),
  // but this crashes real easy under CP2.1/Win95/NC4.06

  public static String VRMLToString( MFString mf_string ) {
    if ( mf_string == null ) return null;

    String new_string = new String();
    int mf_size = mf_string.getSize();
    for ( int i = 0; i < mf_size; i++ )
      new_string = new_string + mf_string.get1Value(i) + " ";

    return new_string;
  }

  // Convert a VRML SFString field into a Java String.

  public static String VRMLToString( SFString sf_string ) {
    if ( sf_string == null ) return null;
    return sf_string.getValue();
  }

}

//
// Class: CoordParser
//
// Author: Martin Reddy, SRI International
//
// This class performs the parsing of VRML coordinate strings
// that contain values in any of a number of geographic coordinate
// systems, and then converting these into earth-fixed geocentric
// values. This class is only accessible to GeoVRML, above.
//

class CoordParser {

  // This value is returned by getNextValue if no data

  public static final double INVALID_VALUE = -987654321.123456789;

  // Internal state for the coordinate parsing

  private int       curr_index;
  private int       no_of_chars;
  private String    curr_string;
  private int       geo_system;

  // Internal state to describe the coordinate system being used

  private Ellipsoid ellipsoid = new WE_Ellipsoid();
  private int       utm_zone = 1;
  private boolean   utm_north = true;
  private boolean   y_first = true;    // latitude_first and northing_first

  // Internal settings for the geo_system flag

  private final int GEO_NONE = 0;
  private final int GEO_GD   = 1;
  private final int GEO_GC   = 2;
  private final int GEO_UTM  = 3;

  // The CoordParser( String, String ) constructor for this class.
  // vertex_string contains a list of coordinates in some coord sys.
  // geoSystem contains the coord system spec, e.g. "GD".

  CoordParser( String vertex_string, String geoSystem ) {
    curr_index = 0;
    geo_system = GEO_NONE;

    // Parse the geoSystem string

    if ( geoSystem != null ) {
      if ( geoSystem.indexOf( "GD" ) >= 0 /* includes GDC and GD */ ) {
	geo_system = GEO_GD;
	ellipsoid = GeoVRML.parseEllipsoid( geoSystem );
      } else if ( geoSystem.indexOf( "UTM" ) >= 0 ) {
	geo_system = GEO_UTM;
	ellipsoid = GeoVRML.parseEllipsoid( geoSystem );
	parseZone( geoSystem );
      } else if ( geoSystem.indexOf( "GC" ) >= 0 /* includes GCC and GC */ ) {
	geo_system = GEO_GC;
      } else
	System.out.println( "Unsupported coord system: " + geoSystem );
    }

    // support the new GeoVRML 1.1 features

    y_first = ( geoSystem.indexOf( "longitude_first" ) < 0 ) &&
              ( geoSystem.indexOf( "easting_first" ) < 0 );

    // Take a copy of the vertex list string

    if ( vertex_string == null ) {
      curr_string = null;
      no_of_chars = 0;
    } else {
      curr_string = new String( vertex_string + " " );
      no_of_chars = curr_string.length();
    }
  }

  CoordParser(String geoSystem ) {
    geo_system = GEO_NONE;

    // Parse the geoSystem string

    if ( geoSystem != null ) {
      if ( geoSystem.indexOf( "GD" ) >= 0 /* includes GDC and GD */ ) {
        geo_system = GEO_GD;
      	ellipsoid = GeoVRML.parseEllipsoid( geoSystem );
      } else if ( geoSystem.indexOf( "UTM" ) >= 0 ) {
      	geo_system = GEO_UTM;
      	ellipsoid = GeoVRML.parseEllipsoid( geoSystem );
      	parseZone( geoSystem );
      } else if ( geoSystem.indexOf( "GC" ) >= 0 /* includes GCC and GS */ ) {
      	geo_system = GEO_GC;
      } else
      	System.out.println( "Unsupported coord system: " + geoSystem );
    }

    // support the new GeoVRML 1.1 features

    y_first = ( geoSystem.indexOf( "longitude_first" ) < 0 ) &&
              ( geoSystem.indexOf( "easting_first" ) < 0 );

  }

  // parse the UTM zone number and hemisphere from a geoSystem string

  private void parseZone( String geoSystem ) {
    int i, j, len = geoSystem.length();

    // If the "S" string is given, then we are in the southern hemisphere

    if ( geoSystem.indexOf( " S" ) >= 0 )
      utm_north = false;

    // parse the zone number, given in a substring as "Z<n>"

    i = geoSystem.indexOf( " Z" );
    if ( i < 0 ) {
      System.out.println( "geoSystem does not specify a UTM zone number!" );
      return;
    }

    // skip any leading whitespace

    i += 2;
    while ( i < len && isWhitespace( geoSystem.charAt(i) ) == true )
      i++;

    // find the end of the zone number

    j = i + 1;
    while ( j < len && isWhitespace( geoSystem.charAt(j) ) == false )
      j++;

    if ( i == j ) {
      System.out.println( "geoSystem UTM zone number is corrupt!" );
      return;
    }

    // convert the string to a integer and update the new zone number

    Integer value = new Integer( geoSystem.substring( i, j ) );
    utm_zone = value.intValue();

    // check that we have a valid zone number

    if ( utm_zone < 1 || utm_zone > 60 ) {
      System.out.println( "UTM Zone number " + utm_zone + " not in [1..60]" );
      utm_zone = 1;
    }

  }


  // isDone returns true if there are no more data entries to be
  // parsed in the vertex string.

  public boolean isDone() {
    if ( curr_string == null || curr_index >= no_of_chars-1 )
      return true;
    return false;
  }

  // a quick method that returns whether a character is to be
  // treated as whitespace for our purposes when parsing a string
  // of coordinates. We make 'Z' a whitespace to simplify parsing
  // UTM coord lists where zone is given as "Z<zone>"

  private static boolean isWhitespace( char symbol ) {
    return ( ( symbol <= ' ' ) || ( symbol == ',' ) || ( symbol == '[' ) ||
             ( symbol == ']' ) || ( symbol == '\"' ) );
  }

  // the getNextValue() method will parse the vertex string and return
  // the double value of the next value in the string. The function
  // returns INVALID_VALUE when we reach the end of the string.

  public double getNextValue() {

    if ( curr_string == null ) return INVALID_VALUE;

    // skip any leading whitespace

    while ( curr_index < no_of_chars &&
	    isWhitespace( curr_string.charAt(curr_index) ) == true )
      curr_index++;
    
    // are there any more data to read?

    if ( isDone() ) return INVALID_VALUE;

    // we have data, so find the end of this token

    int curr_end = curr_index + 1;
    while ( curr_end < no_of_chars &&
	    isWhitespace( curr_string.charAt(curr_end) ) == false )
      curr_end++;

    // convert the string to a double and update the new curr_index

    Double value = new Double( curr_string.substring( curr_index, curr_end ) );
    curr_index = curr_end;

    return value.doubleValue();
  }

  // Method added, Heiko Grussbach

  public Gcc_Coord_3d getNextCoord(double[] p) {
    // Check that we have a geo_system specified and valid data

    if ( geo_system == GEO_NONE) return null;

    // Create the GC return coordinate object

    Gcc_Coord_3d gcc = new Gcc_Coord_3d();

    // read the next 3 values (every geographic coordinate that we
    // support can be expressed in terms of 3 values).

    if ( p[2] == INVALID_VALUE ) return null;

    // Now do the appropriate coordinate conversion to GC
    coordConvert(geo_system,gcc,p[0],p[1],p[2]);

    return gcc;
  }

  // the getNextCoord() method will parse the vertex string and return
  // the next three double values as a geocentric coordinate. The function
  // returns null if there were not 3 data points left.

  public Gcc_Coord_3d getNextCoord() {

    // Check that we have a geo_system specified and valid data

    if ( geo_system == GEO_NONE || isDone() ) return null;

    // Create the GC return coordinate object

    Gcc_Coord_3d gcc = new Gcc_Coord_3d();

    // read the next 3 values (every geographic coordinate that we
    // support can be expressed in terms of 3 values).

    double p1 = getNextValue();
    double p2 = getNextValue();
    double p3 = getNextValue();

    if ( p3 == INVALID_VALUE ) return null;

    // Now do the appropriate coordinate conversion to GC

    coordConvert(geo_system,gcc,p1,p2,p3);

    return gcc;
  }

  public void coordConvert( int geo_system, Gcc_Coord_3d gcc, double p1,
			    double p2, double p3 ) {
    switch ( geo_system ) {
    case GEO_GD:

      // Read a lat/long/elev tuple from the geoCoords strings
      // and convert this into earth-fixed geocentric coordinates

      Gdc_Coord_3d gdc = new Gdc_Coord_3d();

      // support the latitude_first and longitude_first settings

      if ( y_first ) {  
        gdc.latitude  = p1;
        gdc.longitude = p2;
      } else {
        gdc.latitude  = p2;
        gdc.longitude = p1;
      }
      gdc.elevation = p3;

      Gdc_To_Gcc_Converter.Init( ellipsoid );
      Gdc_To_Gcc_Converter.Convert( gdc, gcc );
      break;

    case GEO_GC:

      // Read an earth-fixed geocentric coordinate string
      // This is already in GC coord system so no conversion needed

      gcc.x = p1;
      gcc.y = p2;
      gcc.z = p3;
      break;

    case GEO_UTM:

      // Read a UTM zone/n/e/elev coordinate and
      // convert this into earth-fixed geocentric coordinates

      Utm_Coord_3d utm = new Utm_Coord_3d();

      // support the northing_first and easting_first setting

      if ( y_first ) {
        utm.y    = p1;
        utm.x    = p2;
      } else {
        utm.y    = p2;
        utm.x    = p1;
      }
      utm.z    = p3;
      utm.zone = (byte) utm_zone;

      if ( utm.y < 0.0 ) {  // -ve northings mean southern hemisphere
	utm.hemisphere_north = false;
	utm.y = -utm.y;
      } else
	utm.hemisphere_north = utm_north;

      Utm_To_Gcc_Converter.Init( ellipsoid );
      Utm_To_Gcc_Converter.Convert( utm, gcc );
      break;
    }

  }

}

// EOF: GeoVRML.java
