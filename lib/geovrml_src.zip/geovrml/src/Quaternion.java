//
// Filename: Quaterion.java
//
// Author:
//   Martin Reddy, SRI International (18 Jul 1999)
//
// Purpose:
//   This class provides a basic Quaternion object which contains
//   double-precision floating point x,y,z and w values. Some 
//   quaternion operations are implemented here to the extent that
//   they are required by the GeoVRML class.
//
// License:
//   The contents of this file are subject to GeoVRML Public License
//   Version 1.0 (the "License"); you may not use this file except in
//   compliance with the License. You may obtain a copy of the License at
//   http://www.geovrml.org/1.0/license/.
//
//   Software distributed under the License is distributed on an "AS
//   IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
//   implied. See the License for the specific language governing
//   rights and limitations under the License.
//
//   Portions are Copyright (c) SRI International, 2000.
//
// Revision:
//   $Id: Quaternion.java,v 1.1.1.1 2000/06/15 16:49:26 reddy Exp $
//

package org.web3d.geovrml;

import java.lang.*;

public class Quaternion {

  // the value of this quaterion. A quaternion consists of a vector
  // component (x,y,z) and an angle (w).

  public double x, y, z, w;

  // Constructs and initializes a Quaternion to (0,0,0,0)

  public Quaternion() { x = 0; y = 0; z = 0; w = 0; }

  // Constructs and initializes a Quaternion from the specified coordinates

  public Quaternion( double X, double Y, double Z, double W ) {
    x = X; y = Y; z = Z; w = W;
  }

  // Sets a quaterion given the vector and angle (angle in degrees)

  public void rotation( double a0, double a1, double a2, double phi ) {
    double angle = phi / 2.0 * ( Math.PI / 180.0 );
    double len   = Math.sqrt( a0 * a0 + a1 * a1 + a2 * a2 );
    // double len   = length_v3f (a);
    double scale = Math.sin( angle ) / len;

    // scale_v3f (sin(angle)/len, a, (v3f *) q);
    x = scale * a0;
    y = scale * a1;
    z = scale * a2;

    // Q(*q)[3] = cos(angle);
    w = Math.cos( angle );
  }

  // Sets this quaterion to the sum of the two quaterions q1 and q2

  public void add( Quaternion q1, Quaternion q2 ) {
    // v3f t1, t2;
    double t1[] = new double[3];
    double t2[] = new double[3];

    // scale_v3f (Q(*q2)[3], (v3f *) q1, &t1);
    t1[0] = q2.w * q1.x;
    t1[1] = q2.w * q1.y;
    t1[2] = q2.w * q1.z;
    
    // scale_v3f (Q(*q1)[3], (v3f *) q2, &t2);
    t2[0] = q1.w * q2.x;
    t2[1] = q1.w * q2.y;
    t2[2] = q1.w * q2.z;

    // add_v3f (&t1, &t2, &t1);
    t1[0] = t1[0] + t2[0];
    t1[1] = t1[1] + t2[1];
    t1[2] = t1[2] + t2[2];
    
    // cross_v3f ((v3f *) q2, (v3f *) q1, &t2);
    t2[0] = ( q2.y * q1.z - q2.z * q1.y );
    t2[1] = ( q2.z * q1.x - q2.x * q1.z );
    t2[2] = ( q2.x * q1.y - q2.y * q1.x );

    // add_v3f (&t1, &t2, (v3f *) dest);
    x = t1[0] + t2[0];
    y = t1[1] + t2[1];
    z = t1[2] + t2[2];

    // Q(*dest)[3] = Q(*q1)[3] * Q(*q2)[3] - inner_v3f((v3f *) q1, (v3f *) q2);
    w = q1.w * q2.w - ( q1.x * q2.x + q1.y * q2.y + q1.z * q2.z );

    // normalize_quat (dest);
      
  }

  // Sets this quaterion to the product of the two quaterions q1 and q2
  // see: http://www.cs.berkeley.edu/~laura/cs184/quat/quaternion.html

  public void multiply( Quaternion q1, Quaternion q2 ) {
    w = q1.w * q2.w - q1.x * q2.x - q1.y * q2.y - q1.z * q2.z;
    x = q1.w * q2.x + q1.x * q2.w + q1.y * q2.z - q1.z * q2.y;
    y = q1.w * q2.y - q1.x * q2.z + q1.y * q2.w + q1.z * q2.x;
    z = q1.w * q2.z + q1.x * q2.y - q1.y * q2.x + q1.z * q2.w;
  }

  // returns the normalized axis and angle from a quaterion
  // the angle is returned in radians

  public double axis_angle( double axis[] ) {
    double cos_phi_2 = w;
    double phi_2 = Math.acos( cos_phi_2 );
    double sin_phi_2 = Math.sin( phi_2 );

    // scale_v3f (1/sin_phi_2, (v3f *) Q(*q), axis);
    double scale = 1.0 / sin_phi_2;
    axis[0] = scale * x;
    axis[1] = scale * y;
    axis[2] = scale * z;

    return 2.0 * phi_2;
  }

}

// EOF: Quaternion.java 
